<!-- Content Wrapper. Contains page content -->
</div>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
        <h5>Title</h5>
        <p>Sidebar content</p>
    </div>
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2022-2026 <a href="https://adminlte.io">Leo</a>.</strong> All rights reserved.
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?= base_url('/plugins/jquery/jquery.min.js') ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('/plugins/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('/js/adminlte.min.js') ?>"></script>
</body>

<!-- SCRIPTS -->

<!-- JavaScript Bundle with Popper / Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>

<!--jquery-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--Jquery de tabla, que me paso martin-->
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>


<script>
    $(document).ready(function() {
        $('#torneos-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            }
        });
        $('#equipos-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            }
        });
        $('#fases-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            }
        });
        $('#partidos-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            }
        });
        $('#partidosPronosticos-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            }
        });
        $('#ranking-list').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por pagina",
                "zeroRecords": "No se encontraron coincidencias",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "No hay contenido que mostrar",
                "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                "search": "Buscar: ",
                "paginate": {
                    "next": " Siguiente",
                    "previous": "Anterior "
                }

            },
            "order": [[ "puntos", "desc" ]]
        });
    });
</script>


</html>