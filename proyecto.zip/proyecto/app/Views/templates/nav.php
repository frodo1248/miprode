<nav class="navbar navbar-dark bg-dark navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="http://localhost/proyecto/public/"> <img src="/proyecto/public/img/LOGO-QATAR-2022-4.jpg" alt="Logo Qatar"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="http://localhost/proyecto/public/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Usuarios</a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#">Torneo</a>
                </li> -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Torneos
                    </a>
                    <!-- <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Agregar Torneo</a></li>
                        <li><a class="dropdown-item" href="#">Octavos de Final</a></li>
                        <li><a class="dropdown-item" href="#">Cuartos de Final</a></li>
                        <li><a class="dropdown-item" href="#">Semifinal</a></li>
                        <li><a class="dropdown-item" href="#">Final</a></li>
                         <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Por las dudas</a></li>
                    </ul> -->
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Equipos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="http://localhost/proyecto/public/equipos">Ver Equipos</a></li>
                        <!-- <li><a class="dropdown-item" href="#">Agregar Equipos</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Por las dudas</a></li> -->
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Predicciones
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Ver Predicciones</a></li>
                        <li><a class="dropdown-item" href="#">Prediccion por ususario</a></li>
                        <!-- <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Por las dudas</a></li> -->
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Desafios
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Crear desafios</a></li>
                        <li><a class="dropdown-item" href="#">Unirse a desafios</a></li>
                        <li><a class="dropdown-item" href="#">Ver mis desafios</a></li>
                        <!-- <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Por las dudas</a></li> -->
                    </ul>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Escriba Aquí" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Busqueda</button>
            </form>
        </div>
    </div>
</nav>