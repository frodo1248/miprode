<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">


        <!-- LISTAMOS LOS TORNEOS -->
        <?php if (!empty($torneos)) { ?>

            <h2 class="badge-light text-green text-center display-3 font-italic">De que torneo desea agregar un partido?</h2>

            <?php foreach ($torneos as $torneos_item) : ?>


                <div class="list-group">
                    <a href="<?= base_url('partidos/listarfasespartidos') . '/' . esc($torneos_item['id_torneos'], 'url') ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                        <?= esc($torneos_item['nombre']) ?> -- Empieza el <?= esc($torneos_item['fecha_ini']) ?>
                        -- Termina <?= esc($torneos_item['fecha_fin']) ?>
                    </a>
                </div>

            <?php endforeach ?>


        <?php } else { ?>


            <!-- SE SELECCIONO UN TORNEO -> LISTAMOS LAS FASES -->
            <?php if (!empty($fases)) { ?>

                <?php //dd($fases); 
                ?>
                <h2 class="badge-light text-green text-center display-3 font-italic">De que Fase del Torneo "<u><?php echo ($torneo['nombre']); ?></u>"" desea agregar un partido?</h2>

                <?php foreach ($fases as $fases_item) : ?>


                    <div class="list-group">
                        <a href="<?= base_url('partidos/listapartidos') . '/' . esc($fases_item['id_fases'], 'url') ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                            <?= esc($fases_item['nombre']) ?> -- Empieza el <?= esc($fases_item['fecha_ini']) ?>
                            -- Termina <?= esc($fases_item['fecha_fin']) ?>
                        </a>
                    </div>

                <?php endforeach ?>



            <?php } else { ?>

                <!-- SI EL TORNEO NO TIENE FASES -->
                <?php if (empty($fase)) { ?>

                    <h2 class="badge-light text-green text-center display-3 font-italic">Este Torneo no tiene fases</h2>

                    <!-- SE SELECCIONO UNA FASE -> LISTAMOS LOS PARTIDOS -->
                <?php } else { ?>


                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <h2 class="badge-light text-green text-center display-6 font-italic"> ABM y Listado de partidos del torneo "<u><?php echo ($fase->nombreTorneo); ?></u>" de la fase "<u><?php echo ($fase->nombre) ?></u>"</h2>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 col-xl-3">


                        <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>

                        <?php if (session('mensaje')) { ?>

                            <div class="alert alert-danger" role="alert">
                                <ul>

                                    <li><?= esc(session('mensaje')) ?></li>

                                </ul>
                            </div>

                        <?php } ?>

                        <?php

                        if (!empty($partido)) {


                        ?>

                            <!-- MODIFICAR PARTIDO -->
                            <h2>Modificar Partido</h2>
                            <form action="<?= base_url('partidos/savepartido') ?>" method="post">
                                <?= csrf_field() //genera en input hidden, esto me garantiza que 
                                //coincida ese valor y que no pueda hacer un post de otro lado 
                                ?>

                                <!-- FECHA Y HORA -->
                                <div class="mb-3">
                                    <label for="fecha_y_horaInput" class="form-label">Fecha y Hora</label>
                                    <input type="datetime-local" name="fecha_y_hora" value="<?php echo $partido['fecha_y_hora'] ?>" class="form-control" id="idNombreInput" placeholder="Fecha y Hora" required>
                                </div>

                                <!-- FASE -->
                                <div class="mb-3">
                                    <label for="faseInput" class="form-label">Fase <?php echo ($fase->nombre); ?></label>
                                    <input type="hidden" name="fases_id_fases" value="<?php echo ($fase->id_fases); ?>">
                                </div>

                                <!-- <div class="mb-3">
                                    <label for="faseInput" class="form-label">Fases</label>

                                    <?php //if (!empty($fases) && is_array($fases)) : 
                                    ?>

                                        <?php //foreach ($fases as $fases_item) : 
                                        ?>

                                            <?php

                                            //$nombresFases[$fases_item['id_fases']] = $fases_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php //endforeach 
                                        ?>

                                        <?php


                                        //echo form_dropdown('fases_id_fases', $nombresFases, $partido['fases_id_fases']);
                                        ?>

                                    <?php //else : 
                                    ?>

                                        <p>No hay Fases</p>

                                    <?php //endif 
                                    ?>

                                </div> -->


                                <!-- LOCAL -->
                                <div class="mb-3">
                                    <label for="equipoLocalInput" class="form-label">Equipo Local</label>

                                    <?php if (!empty($equipos) && is_array($equipos)) : ?>

                                        <?php foreach ($equipos as $equipos_item) : ?>

                                            <?php

                                            $nombresEquipos[$equipos_item['id_equipos']] = $equipos_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php endforeach ?>

                                        <?php


                                        echo form_dropdown('equipos_id_equipos_local', $nombresEquipos, $partido['equipos_id_equipos_local']);
                                        ?>

                                    <?php else : ?>

                                        <p>No hay Equipos</p>

                                    <?php endif ?>

                                </div>

                                <!-- VISITANTE -->
                                <div class="mb-3">
                                    <label for="equipoVisitanteInput" class="form-label">Equipo Visitante</label>

                                    <?php if (!empty($equipos) && is_array($equipos)) : ?>

                                        <?php foreach ($equipos as $equipos_item) : ?>

                                            <?php

                                            $nombresEquipos[$equipos_item['id_equipos']] = $equipos_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php endforeach ?>

                                        <?php


                                        echo form_dropdown('equipos_id_equipos_visitante', $nombresEquipos, $partido['equipos_id_equipos_visitante']);
                                        ?>

                                    <?php else : ?>

                                        <p>No hay Equipos</p>

                                    <?php endif ?>

                                </div>

                                <!-- GRUPO -->
                                <?php if (!$fase->es_eliminatoria == '1') : ?>
                                    <div class="mb-3">
                                        <label for="gruposInput" class="form-label">Grupos</label>

                                        <?php if (!empty($grupos) && is_array($grupos)) : ?>

                                            <?php foreach ($grupos as $grupos_item) : ?>

                                                <?php

                                                $nombresGrupos[$grupos_item['id_grupos']] = $grupos_item['nombre'];

                                                //print_r($nombres);

                                                ?>

                                            <?php endforeach ?>

                                            <?php


                                            echo form_dropdown('grupos_id_grupos', $nombresGrupos, $partido['grupos_id_grupos']);
                                            ?>

                                        <?php else : ?>

                                            <p>No hay Grupos</p>

                                        <?php endif ?>

                                    </div>
                                <?php endif ?>

                                <!-- RESULTADO -->


                                <!-- BOTONES -->
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <a href="<?= base_url('partidos/listapartidos') . '/' . esc($fase->id_fases, 'url') ?>" class="btn btn-secondary">Cancelar</a>

                                    <input type="hidden" name="id_partidos" value="<?php echo $partido['id_partidos']; ?>">

                                </div>

                            </form>

                        <?php
                        } else {
                        ?>

                            <!-- NUEVO PARTIDO -->
                            <h2>Nuevo Partido</h2>

                            <form action="<?= base_url('partidos/savepartido') ?>" method="post">
                                <?= csrf_field() //genera en input hidden, esto me garantiza que 
                                //coincida ese valor y que no pueda hacer un post de otro lado 
                                ?>

                                <!-- FECHA Y HORA -->
                                <div class="mb-3">
                                    <label for="nombreInput" class="form-label">Fecha y Hora</label>
                                    <input type="datetime-local" name="fecha_y_hora" value="<?= set_value('fecha_y_hora') ?>" class="form-control" id="idNombreInput" placeholder="Fecha y Hora" required>
                                </div>

                                <!-- FASE -->
                                <div class="mb-3">
                                    <label for="faseInput" class="form-label">Fase <?php echo ($fase->nombre); ?></label>
                                    <input type="hidden" name="fases_id_fases" value="<?php echo ($fase->id_fases); ?>">
                                </div>

                                <!-- <div class="mb-3">
                                    <label for="faseInput" class="form-label">Fases</label>

                                    <?php //if (!empty($fases) && is_array($fases)) : 
                                    ?>

                                        <?php //foreach ($fases as $fases_item) : 
                                        ?>

                                            <?php

                                            //$nombresFases[$fases_item['id_fases']] = $fases_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php //endforeach 
                                        ?>

                                        <?php


                                        //echo form_dropdown('fases_id_fases', $nombresFases) //, $fases['fases_id_fases']); 
                                        ?>

                                    <?php //else : 
                                    ?>

                                        <p>No hay Fases</p>

                                    <?php //endif 
                                    ?>

                                </div> -->


                                <!-- LOCAL -->
                                <div class="mb-3">
                                    <label for="equipoLocalInput" class="form-label">Equipo Local</label>

                                    <?php if (!empty($equipos) && is_array($equipos)) : ?>

                                        <?php foreach ($equipos as $equipos_item) : ?>

                                            <?php

                                            $nombresEquipos[$equipos_item['id_equipos']] = $equipos_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php endforeach ?>

                                        <?php


                                        echo form_dropdown('equipos_id_equipos_local', $nombresEquipos) //, $equipos['equipos_id_equipos_local']);equipos_id_equipos_visitante 
                                        ?>

                                    <?php else : ?>

                                        <p>No hay Equipos</p>

                                    <?php endif ?>

                                </div>

                                <!-- VISITANTE -->
                                <div class="mb-3">
                                    <label for="equipoVisitanteInput" class="form-label">Equipo Visitante</label>

                                    <?php if (!empty($equipos) && is_array($equipos)) : ?>

                                        <?php foreach ($equipos as $equipos_item) : ?>

                                            <?php

                                            $nombresEquipos[$equipos_item['id_equipos']] = $equipos_item['nombre'];

                                            //print_r($nombres);

                                            ?>

                                        <?php endforeach ?>

                                        <?php


                                        echo form_dropdown('equipos_id_equipos_visitante', $nombresEquipos) //, $equipos['equipos_id_equipos_visitante']); 
                                        ?>

                                    <?php else : ?>

                                        <p>No hay Equipos</p>

                                    <?php endif ?>

                                </div>

                                <!-- GRUPO -->
                                <?php //dd($fase->es_eliminatoria); 
                                ?>
                                <?php if (!$fase->es_eliminatoria == '1') : ?>

                                    <div class="mb-3">
                                        <label for="gruposInput" class="form-label">Grupos</label>

                                        <?php if (!empty($grupos) && is_array($grupos)) : ?>

                                            <?php foreach ($grupos as $grupos_item) : ?>

                                                <?php

                                                $nombresGrupos[$grupos_item['id_grupos']] = $grupos_item['nombre'];

                                                //print_r($nombres);

                                                ?>

                                            <?php endforeach ?>

                                            <?php


                                            echo form_dropdown('grupos_id_grupos', $nombresGrupos);
                                            ?>

                                        <?php else : ?>

                                            <p>No hay Equipos</p>

                                        <?php endif ?>

                                    </div>

                                <?php endif ?>



                                <!-- BOTONES -->
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <button type="reset" class="btn btn-secondary">Limpiar</button>
                                </div>

                            </form>

                        <?php } ?>

                    </div>

                    <div class="col-sm-12 col-md-9 col-lg-9 col-xl-9">

                        <h2>Listado de Partidos</h2>

                        <table class="table table-striped table-primary text-center justify-content-center" id="partidos-list">
                            <thead>
                                <tr>
                                    <th>Fecha y Hora</th>
                                    <th>Local</th>
                                    <th>Visitante</th>
                                    <th>Resultado</th>
                                    <th>Fase</th>
                                    <?php if (!$fase->es_eliminatoria == '1') : ?>
                                        <th>Grupo</th>
                                    <?php endif ?>
                                    <th>Editar</th>
                                    <th>Eliminar</th>
                                </tr>
                            </thead>
                            <tbody>


                                <?php if (!empty($partidos) && is_array($partidos)) : ?>

                                    <?php foreach ($partidos as $partidos_item) : ?>

                                        <?php //dd($partidos_item);
                                        ?>

                                        <TR>
                                            <!-- FECHA Y HORA -->
                                            <TD><?= date_format(new DateTime($partidos_item->fecha_y_hora), 'd M y - H:i') ?></TD>

                                            <!-- LOCAL -->
                                            <TD><?= $partidos_item->local //esc($nombresEquipos[$partidos_item->equipos_id_equipos_local]) 
                                                ?></TD>

                                            <!-- VISITANTE -->
                                            <TD><?= $partidos_item->visitante //esc($nombresEquipos[$partidos_item['equipos_id_equipos_visitante']]) 
                                                ?></TD>

                                            <!-- RESULTADO -->
                                            <TD><?= $partidos_item->resultado //esc($partidos_item['resultado']) 
                                                ?></TD>

                                            <!-- FASE -->
                                            <TD><?= $fase->nombre //esc($fases[$partidos_item->fases_id_fases]->nombreFase) //$partidos_item->fases_id_fases //esc($nombresFases[$partidos_item['fases_id_fases']]) 
                                                ?></TD>

                                            <!-- GRUPO -->
                                            <?php if (!$fase->es_eliminatoria == '1') : ?>
                                                <TD><?php
                                                    //dd($partidos_item);
                                                    if ($partidos_item->grupos_id_grupos == null) {
                                                        echo ('');
                                                    } else {
                                                        echo ($nombresGrupos[$partidos_item->grupos_id_grupos]); //lo mismo que arriba 
                                                    }
                                                    ?> </TD>
                                            <?php endif ?>

                                            <!-- EDITAR -->
                                            <td>
                                                <a href="<?= base_url('/partidos') . '/' . $partidos_item->id_partidos ?>">
                                                    <button class="btn btn-warning"><img src=<?= base_url('/img/iconoEditar.png') ?> alt="" class="iconos">
                                                    </button>
                                                </a>
                                            </td>

                                            <!-- ELIMINAR -->
                                            <td>
                                                <a href="<?= base_url('partidos/bajapartido') . '/' . $partidos_item->id_partidos ?>">

                                                    <button class="btn btn-danger">
                                                        <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                                    </button>
                                                </a>
                                            </td>

                                        </TR>

                                    <?php endforeach ?>

                                <?php else : ?>

                                    <h3>No hay partidos</h3>

                                    <p>No se encontraron partidos</p>

                                <?php endif ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- BOTON VOLVER FASES-->
                    <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">

                        <a href="<?= base_url('partidos/listarfasespartidos') . '/' . esc($fase->id_torneos, 'url') ?>" class="btn btn-secondary">Volver a Fases</a>

                    </div>
                <?php } ?>
            <?php } ?>
            <!-- BOTON VOLVER TORNEOS-->
            <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">

                <a href="<?= base_url('partidos') ?>" class="btn btn-secondary">Volver a Torneos</a>

            </div>
        <?php } ?>
    </div>
</div>