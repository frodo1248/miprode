<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <?php if (!empty($misDesafios)) { ?>

            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">

                <h2>Tus Desafios</h2>

                <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Torneo</th>
                            <th>Invitar amigos</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>




                        <?php if (!empty($misDesafios) && is_array($misDesafios)) : ?>

                            <?php foreach ($misDesafios as $desafios_item) : ?>

                                <TR>
                                    <!-- NOMBRE -->
                                    <TD><?= $desafios_item->nombre ?></TD>

                                    <!-- TORNEOS -->
                                    <TD><?= $desafios_item->nombreTorneo ?></TD>

                                    <!-- IVITAR AMIGOS -->
                                    <td>
                                        <a href="<?= base_url('/invitaciones/crearinvitacion') . '/' . esc($desafios_item->id_desafios, 'url') ?>">
                                            <button class="btn btn-warning"><img src=<?= base_url('/img/agregarUsuario.png') ?> alt="" class="iconos">
                                            </button>
                                        </a>
                                    </td>

                                    <TD><?php //esc($nombres[$fases_item['torneos_id_torneos']]) 
                                        ?></TD>


                                    <!-- DE MOMENTO SAQUE LO DE EDITAR Y ELIMINAR DESAFIOS, PREGUNTAR -->

                                </TR>

                            <?php endforeach ?>

                        <?php else : ?>

                            <!-- <h3>No hay Fases</h3>

                            <p>No se encontraron Fases</p> -->

                            <h3>No se encontraron Desafios</h3>

                        <?php endif ?>



                    </tbody>
                </table>
            </div>

        <?php } else { ?>

            <?php //dd($torneos); 
            ?>
            <!-- LISTAMOS LOS TORNEOS -->
            <?php if (!empty($torneos)) { ?>

                <h2 class="badge-light text-green text-center display-3 font-italic">En que torneo quiere Desafiar a sus amigos</h2>

                <?php foreach ($torneos as $torneos_item) : ?>
                    <?php //dd($torneos_item['id_torneos']); 
                    ?>

                    <div class="list-group">
                        <a href="<?= base_url('desafios/creardesafio') . '/' . esc($torneos_item->id_torneos) ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                            <?= esc($torneos_item->nombre) ?> -- Empieza el <?= esc($torneos_item->fecha_ini) ?>
                            -- Termina <?= esc($torneos_item->fecha_fin) ?>
                        </a>
                    </div>

                <?php endforeach ?>


            <?php } else { ?>


                <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                    <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>
                    <?php

                    if (!empty($fase)) { ?>

                        <h2>Modificar Fase</h2>

                        <form action="<?= base_url('fases/savefase') ?>" method="post">
                            <?= csrf_field() //genera en input hidden, esto me garantiza que 
                            //coincida ese valor y que no pueda hacer un post de otro lado 
                            ?>
                            <!-- NOMBRE -->
                            <div class="mb-3">
                                <label for="nombreInput" class="form-label">Nombre de la Fase</label>
                                <input type="text" name="nombre" value="<?php echo $fase['nombre'] ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                            </div>

                            <!-- FECHA DE INICIO -->
                            <div class="mb-3">
                                <label for="fecha_iniInput" class="form-label">Fecha de Inicio</label>
                                <input type="date" name="fecha_ini" value="<?php echo $fase['fecha_ini'] ?>" class="form-control" id="idFecha_iniInput" placeholder="Fecha_ini" required>
                            </div>

                            <!-- FECHA DE FIN -->
                            <div class="mb-3">
                                <label for="fecha_finInput" class="form-label">Fecha de Fin</label>
                                <input type="date" name="fecha_fin" value="<?php echo $fase['fecha_fin'] ?>" class="form-control" id="idFecha_finInput" placeholder="Fecha_fin" required>
                            </div>


                            <!-- ES ELIMINTORIA -->
                            <div class="mb-3">
                                <label for="fecha_finInput" class="form-label">Fase elimnatoria: </label>


                                <input type="radio" name="es_eliminatoria" value="1" <?= $fase['es_eliminatoria'] == '1' ? 'checked' : '' ?> required>
                                <label for="fecha_finInput" class="form-label">Si</label>

                                <input type="radio" name="es_eliminatoria" value="0" <?= $fase['es_eliminatoria'] == '0' ? 'checked' : '' ?> required>
                                <label for="fecha_finInput" class="form-label">No</label>

                            </div>


                            <!-- TORNEO -->
                            <div class="mb-3">
                                <input type="hidden" name="torneos_id_torneos" value="<?php echo $fase['torneos_id_torneos']; ?>">
                            </div>

                            <!-- TORNEOS quite que se pueda modificar el torneo al que pertenece-->
                            <!-- <div class="mb-3">
                            <label for="torneoInput" class="form-label">Torneo</label>

                            <?php //if (!empty($torneos) && is_array($torneos)) : 
                            ?>

                                <?php //foreach ($torneos as $torneos_item) : 
                                ?>

                                    <?php

                                    //$nombres[$torneos_item['id_torneos']] = $torneos_item['nombre'];

                                    //print_r($nombres);

                                    ?>

                                <?php //endforeach 
                                ?>

                                <?php

                                // dd($fase['torneos_id_torneos']);
                                // echo form_dropdown('torneos_id_torneos', $nombres, $fase['torneos_id_torneos']); 
                                ?>

                            <?php //else : 
                            ?>

                                <p>No hay Torneos</p>

                            <?php //endif 
                            ?>

                        </div> -->

                            <!-- BOTONES -->
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <a href="<?= base_url('fases/mostrarfase') . '/' . esc($fase['torneos_id_torneos']) ?>" class="btn btn-secondary">Cancelar</a>

                                <input type="hidden" name="id_fases" value="<?php echo $fase['id_fases']; ?>">

                            </div>

                        </form>

                    <?php
                    } else {
                    ?>

                        <h2>Nuevo Desafio</h2>

                        <form action="<?= base_url('desafios/savedesafio') ?>" method="post">
                            <!--usar base url-->
                            <?= csrf_field() //genera en input hidden, esto me garantiza que 
                            //coincida ese valor y que no pueda hacer un post de otro lado 
                            ?>

                            <!-- NOMBRE -->
                            <div class="mb-3">
                                <label for="nombreInput" class="form-label">Nombre del Desafio</label>
                                <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                            </div>

                            <!-- TORNEO -->
                            <div class="mb-3">
                                <input type="hidden" name="torneos_id_torneos" value="<?php echo $torneo['id_torneos']; ?>">
                            </div>


                            <!-- BOTONES -->
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <button type="reset" class="btn btn-secondary">Limpiar</button>
                            </div>

                        </form>

                    <?php } ?>

                </div>

                <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">

                    <h2>Tus Desafios</h2>

                    <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Editar</th>
                                <th>Invitar amigos</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>
                        <tbody>




                            <?php if (!empty($desafios) && is_array($desafios)) : ?>

                                <?php foreach ($desafios as $desafios_item) : ?>

                                    <TR>
                                        <!-- NOMBRE -->
                                        <TD><?= esc($desafios_item['nombre']) ?></TD>



                                        <!-- TORNEOS- SE SACO POR QUE AHORA LO LISTO ANTES Y LO SELECCIONO AHI -->
                                        <TD><?php //esc($nombres[$fases_item['torneos_id_torneos']]) 
                                            ?></TD>


                                        <!-- IVITAR AMIGOS -->
                                        <td>
                                            <a href="<?= base_url('/invitaciones/crearinvitacion') . '/' . esc($desafios_item['id_desafios'], 'url') ?>">
                                                <button class="btn btn-warning"><img src=<?= base_url('/img/agregarUsuario.png') ?> alt="" class="iconos">
                                                </button>
                                            </a>
                                        </td>


                                        <!-- DE MOMENTO SAQUE LO DE EDITAR Y ELIMINAR DESAFIOS, PREGUNTAR -->

                                    </TR>

                                <?php endforeach ?>

                            <?php else : ?>

                                <!-- <h3>No hay Fases</h3>

                            <p>No se encontraron Fases</p> -->

                                <h3>No se encontraron Desafios</h3>

                            <?php endif ?>



                        </tbody>
                    </table>
                </div>


                <!-- BOTON VOLVER TORNEOS-->
                <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-4 py-4">

                    <a href="<?= base_url('/desafios') ?>" class="btn btn-dark">Volver a elegir Torneo</a>

                </div>


            <?php } ?>
        <?php } ?>
    </div>
</div>