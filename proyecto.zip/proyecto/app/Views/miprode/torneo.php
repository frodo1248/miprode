<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

            <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>
            <?php

            if (!empty($torneo)) { ?>

                <h2>Modificar Torneo</h2>

                <form action="<?= base_url('torneos/savetorneo') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>

                    <!-- NOMBRE -->
                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Torneo</label>
                        <input type="text" name="nombre" value="<?php echo $torneo['nombre'] ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>

                    <!-- FECHA DE INICIO -->
                    <div class="mb-3">
                        <label for="fecha_iniInput" class="form-label">Fecha de Inicio</label>
                        <input type="date" name="fecha_ini" value="<?php echo $torneo['fecha_ini'] ?>" min="<?= date('Y-m-d') ?>" class="form-control" id="idFecha_iniInput" placeholder="Fecha_ini" required>
                    </div>

                    <!-- FECHA DE FIN -->
                    <div class="mb-3">
                        <label for="fecha_finInput" class="form-label">Fecha de Fin</label>
                        <input type="date" name="fecha_fin" value="<?php echo $torneo['fecha_fin'] ?>" class="form-control" id="idFecha_finInput" placeholder="Fecha_fin" required>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="<?= base_url('torneos'); ?>" class="btn btn-secondary">Cancelar</a>

                        <input type="hidden" name="id_torneos" value="<?php echo $torneo['id_torneos']; ?>">

                    </div>

                </form>


            <?php
            } else {
            ?>

                <h2>Nuevo Torneo</h2>
                <form action="<?= base_url('torneos/savetorneo') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>
                    <!-- NOMBRE -->
                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Torneo</label>
                        <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>

                    <!-- FECHA DE INICIO -->
                    <div class="mb-3">
                        <label for="fecha_iniInput" class="form-label">Fecha de Inicio</label>
                        <input type="date" name="fecha_ini" value="<?= set_value('fecha_ini') ?>" min="<?= date('Y-m-d') ?>" class="form-control" id="idFecha_iniInput" placeholder="Fecha_ini" required>
                    </div>

                    <!-- FECHA DE FIN -->
                    <div class="mb-3">
                        <label for="fecha_finInput" class="form-label">Fecha de Fin</label>
                        <input type="date" name="fecha_fin" value="<?= set_value('fecha_fin') ?>" min="<?= date('Y-m-d') ?>" class="form-control" id="idFecha_finInput" placeholder="Fecha_fin" required>
                    </div>

                    <!-- BOTONES -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <button type="reset" class="btn btn-secondary">Limpiar</button>

                    </div>

                </form>



            <?php } ?>

        </div>

        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">

            <h2>Listado de Torneos</h2>

            <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Fecha de Inicio</th>
                        <th>Fecha de Fin</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>




                    <?php if (!empty($torneos) && is_array($torneos)) : ?>

                        <?php foreach ($torneos as $torneos_item) : ?>

                            <TR>
                                <!-- NOMBRE -->
                                <TD><?= esc($torneos_item['nombre']) ?></TD>

                                <!-- FECHA DE INICIO -->
                                <TD><?= esc($torneos_item['fecha_ini']) ?></TD>

                                <!-- FECHA DE FIN -->
                                <TD><?= esc($torneos_item['fecha_fin']) ?></TD>

                                <!-- EDITAR -->
                                <td>
                                    <a href="<?= base_url('/torneos') . '/' . esc($torneos_item['id_torneos'], 'url') ?>">
                                        <button class="btn btn-warning"><img src=<?= base_url('/img/iconoEditar.png') ?> alt="" class="iconos">
                                        </button>
                                    </a>
                                </td>

                                <!-- ELIMINAR -->
                                <td>
                                    <a href="<?= base_url('torneos/bajatorneo') . '/' . esc($torneos_item['id_torneos'], 'url') ?>">

                                        <button class="btn btn-danger">
                                            <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                        </button>
                                    </a>
                                </td>

                            </TR>







                        <?php endforeach ?>

                    <?php else : ?>

                        <h3>No hay Torneos</h3>

                        <p>No se encontraron Torneos</p>

                    <?php endif ?>



                </tbody>
            </table>
        </div>


    </div>
</div>