<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">



        <?php //dd($torneos); 
        ?>
        <!-- LISTAMOS LOS TORNEOS -->
        <?php if (!empty($torneos)) { ?>

            <h2 class="badge-light text-green text-center display-3 font-italic">Seleccione un torneo</h2>

            <?php foreach ($torneos as $torneos_item) : ?>
                <?php //dd($torneos_item['id_torneos']); 
                ?>

                <div class="list-group">
                    <a href="<?= base_url('fases/mostrarfase') . '/' . esc($torneos_item['id_torneos']) ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                        <?= esc($torneos_item['nombre']) ?> -- Empieza el <?= esc($torneos_item['fecha_ini']) ?>
                        -- Termina <?= esc($torneos_item['fecha_fin']) ?>
                    </a>
                </div>

            <?php endforeach ?>


        <?php } else { ?>


            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>
                <?php

                if (!empty($fase)) { ?>

                    <h2>Modificar Fase</h2>

                    <form action="<?= base_url('fases/savefase') ?>" method="post">
                        <?= csrf_field() //genera en input hidden, esto me garantiza que 
                        //coincida ese valor y que no pueda hacer un post de otro lado 
                        ?>
                        <!-- NOMBRE -->
                        <div class="mb-3">
                            <label for="nombreInput" class="form-label">Nombre de la Fase</label>
                            <input type="text" name="nombre" value="<?php echo $fase['nombre'] ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                        </div>

                        <!-- FECHA DE INICIO -->
                        <div class="mb-3">
                            <label for="fecha_iniInput" class="form-label">Fecha de Inicio</label>
                            <input type="date" name="fecha_ini" value="<?php echo $fase['fecha_ini'] ?>" class="form-control" id="idFecha_iniInput" placeholder="Fecha_ini" required>
                        </div>

                        <!-- FECHA DE FIN -->
                        <div class="mb-3">
                            <label for="fecha_finInput" class="form-label">Fecha de Fin</label>
                            <input type="date" name="fecha_fin" value="<?php echo $fase['fecha_fin'] ?>" class="form-control" id="idFecha_finInput" placeholder="Fecha_fin" required>
                        </div>


                        <!-- ES ELIMINTORIA -->
                        <div class="mb-3">
                            <label for="fecha_finInput" class="form-label">Fase elimnatoria: </label>


                            <input type="radio" name="es_eliminatoria" value="1" <?= $fase['es_eliminatoria'] == '1' ? 'checked' : '' ?> required>
                            <label for="fecha_finInput" class="form-label">Si</label>

                            <input type="radio" name="es_eliminatoria" value="0" <?= $fase['es_eliminatoria'] == '0' ? 'checked' : '' ?> required>
                            <label for="fecha_finInput" class="form-label">No</label>

                        </div>


                        <!-- TORNEO -->
                        <div class="mb-3">
                            <input type="hidden" name="torneos_id_torneos" value="<?php echo $fase['torneos_id_torneos']; ?>">
                        </div>

                        <!-- TORNEOS quite que se pueda modificar el torneo al que pertenece-->
                        <!-- <div class="mb-3">
                            <label for="torneoInput" class="form-label">Torneo</label>

                            <?php //if (!empty($torneos) && is_array($torneos)) : 
                            ?>

                                <?php //foreach ($torneos as $torneos_item) : 
                                ?>

                                    <?php

                                    //$nombres[$torneos_item['id_torneos']] = $torneos_item['nombre'];

                                    //print_r($nombres);

                                    ?>

                                <?php //endforeach 
                                ?>

                                <?php

                                // dd($fase['torneos_id_torneos']);
                                // echo form_dropdown('torneos_id_torneos', $nombres, $fase['torneos_id_torneos']); 
                                ?>

                            <?php //else : 
                            ?>

                                <p>No hay Torneos</p>

                            <?php //endif 
                            ?>

                        </div> -->

                        <!-- BOTONES -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                            <a href="<?= base_url('fases/mostrarfase') . '/' . esc($fase['torneos_id_torneos']) ?>" class="btn btn-secondary">Cancelar</a>

                            <input type="hidden" name="id_fases" value="<?php echo $fase['id_fases']; ?>">

                        </div>

                    </form>

                <?php
                } else {
                ?>

                    <h2>Nueva Fase</h2>

                    <form action="<?= base_url('fases/savefase') ?>" method="post">
                        <!--usar base url-->
                        <?= csrf_field() //genera en input hidden, esto me garantiza que 
                        //coincida ese valor y que no pueda hacer un post de otro lado 
                        ?>

                        <!-- NOMBRE -->
                        <div class="mb-3">
                            <label for="nombreInput" class="form-label">Nombre de la Fase</label>
                            <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                        </div>

                        <!-- FECHA DE INICIO -->
                        <div class="mb-3">
                            <label for="fecha_iniInput" class="form-label">Fecha de Inicio</label>
                            <input type="date" name="fecha_ini" value="<?= set_value('fecha_ini') ?>" class="form-control" id="idFecha_iniInput" placeholder="Fecha_ini" required>
                        </div>

                        <!-- FECHA DE FIN -->
                        <div class="mb-3">
                            <label for="fecha_finInput" class="form-label">Fecha de Fin</label>
                            <input type="date" name="fecha_fin" value="<?= set_value('fecha_fin') ?>" class="form-control" id="idFecha_finInput" placeholder="Fecha_fin" required>
                        </div>

                        <!-- ES ELIMINTORIA -->
                        <div class="mb-3">
                            <label for="fecha_finInput" class="form-label">Fase elimnatoria: </label>


                            <input type="radio" name="es_eliminatoria" value="1" <?= set_value('es_eliminatoria') ?> required>
                            <label for="fecha_finInput" class="form-label">Si</label>

                            <input type="radio" name="es_eliminatoria" value="0" <?= set_value('es_eliminatoria') ?> required>
                            <label for="fecha_finInput" class="form-label">No</label>

                        </div>


                        <!-- TORNEO -->
                        <div class="mb-3">
                            <input type="hidden" name="torneos_id_torneos" value="<?php echo $torneo['id_torneos']; ?>">
                        </div>



                        <!-- TORNEOS- SE SACO POR QUE AHORA LO LISTO ANTES Y LO SELECCIONO AHI -->
                        <!-- <div class="mb-3">
                            <label for="torneoInput" class="form-label">Torneo</label>

                            <?php //if (!empty($torneos) && is_array($torneos)) : 
                            ?>

                                <?php //foreach ($torneos as $torneos_item) : 
                                ?>

                                    <?php

                                    //$nombres[$torneos_item['id_torneos']] = $torneos_item['nombre'];

                                    //print_r($nombres);

                                    ?>

                                <?php //endforeach 
                                ?>

                                <?php //echo form_dropdown('torneos_id_torneos', $nombres); 
                                ?>

                            <?php //else : 
                            ?>

                                <p>No hay Torneos</p>

                            <?php //endif 
                            ?>

                        </div> -->


                        <!-- BOTONES -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                            <button type="reset" class="btn btn-secondary">Limpiar</button>
                        </div>

                    </form>

                <?php } ?>

            </div>

            <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">

                <h2>Listado de Fases</h2>

                <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha de Inicio</th>
                            <th>Fecha de Fin</th>
                            <th>Eliminatoria</th>
                            <th>Torneo</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>




                        <?php if (!empty($fases) && is_array($fases)) : ?>

                            <?php foreach ($fases as $fases_item) : ?>

                                <TR>
                                    <!-- NOMBRE -->
                                    <TD><?= esc($fases_item['nombre']) ?></TD>

                                    <!-- FECHA DE INICIO -->
                                    <TD><?php echo (date_format(new DateTime($fases_item['fecha_ini']), 'D/m/Y')); ?></TD>

                                    <!-- FECHA DE FIN -->
                                    <TD><?= esc($fases_item['fecha_fin']) ?></TD>

                                    <!-- ELIMINATORIA -->
                                    <TD><?php
                                        if ($fases_item['es_eliminatoria'] == 1) {
                                            echo ('Si');
                                        } else {
                                            echo ('No');
                                        }

                                        ?></TD>


                                    <!-- TORNEOS- SE SACO POR QUE AHORA LO LISTO ANTES Y LO SELECCIONO AHI -->
                                    <TD><?php //esc($nombres[$fases_item['torneos_id_torneos']]) 
                                        ?></TD>

                                    <!-- EDITAR -->
                                    <td>
                                        <a href="<?= base_url('/fases') . '/' . esc($fases_item['id_fases'], 'url') ?>">
                                            <button class="btn btn-warning"><img src=<?= base_url('/img/iconoEditar.png') ?> alt="" class="iconos">
                                            </button>
                                        </a>
                                    </td>

                                    <!-- ELIMINAR -->
                                    <td>
                                        <a href="<?= base_url('fases/bajafase') . '/' . esc($fases_item['id_fases'], 'url') ?>">

                                            <button class="btn btn-danger">
                                                <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                            </button>
                                        </a>
                                    </td>

                                </TR>

                            <?php endforeach ?>

                        <?php else : ?>

                            <h3>No hay Fases</h3>

                            <p>No se encontraron Fases</p>

                        <?php endif ?>



                    </tbody>
                </table>
            </div>


            <!-- BOTON VOLVER TORNEOS-->
            <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-4 py-4">

                <a href="<?= base_url('/fases') ?>" class="btn btn-dark">Volver a Torneos</a>

            </div>


        <?php } ?>
    </div>
</div>