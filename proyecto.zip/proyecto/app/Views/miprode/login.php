<!--Coded with love by Mutiullah Samim-->
<div class="container my-5 py-5 fondo-personalizado">
    <div class="container h-100">
        <div class="d-flex justify-content-center h-100">
            <div class="user_card">
                <div class="d-flex justify-content-center">
                    <div class="brand_logo_container">
                        <img src="https://cdn.freebiesupply.com/logos/large/2x/pinterest-circle-logo-png-transparent.png" class="brand_logo" alt="Logo">
                    </div>
                </div>
                <div class="d-flex justify-content-center form_container">

                    <form action="<?= base_url('login')?>" method="post">
                        <?= csrf_field() //genera en input hidden, esto me garantiza que 
                        //coincida ese valor y que no pueda hacer un post de otro lado 
                        ?>

                        <div class="input-group mb-3">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" name="usuario" class="form-control input_user" value="" placeholder="usuario">
                        </div>
                        <div class="input-group mb-2">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" name="contraseña" class="form-control input_pass" value="" placeholder="contraseña">
                        </div>
                        <div class="form-group">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="customControlInline">
                                <label class="custom-control-label" for="customControlInline">Recuerdame</label>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center mt-3 login_container">
                            <button type="submit" name="button" class="btn login_btn">Iniciar Sesión</button>
                        </div>
                    </form>
                </div>

                <div class="mt-4">
                    <div class="d-flex justify-content-center links">
                        No tienes cuenta? <a href="<?= base_url('usuariosnuevos/index') ?>" class="ml-2">Registrate</a>
                    </div>
                    <div class="d-flex justify-content-center links">
                        <a href="#">Olvide mi contraseña?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>