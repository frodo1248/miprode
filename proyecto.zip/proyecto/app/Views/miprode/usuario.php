<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

            <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>
            <?php

            if (!empty($usuario)) {


            ?>



                <h2>Modificar Usuario</h2>
                <form action="<?= base_url('usuarios/saveusuario') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>

                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Usuario</label>
                        <input type="text" name="nombre" value="<?php echo $usuario['nombre'] ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>



                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="<?= base_url('usuarios') ?>" class="btn btn-secondary">Cancelar</a>

                        <input type="hidden" name="id_usuarios" value="<?php echo $usuario['id_usuarios']; ?>">
                        <!--Hace falta que le envie otro id para hacer el update, si no me crea otro registro-->

                      


                    </div>

                </form>


            <?php
            } else {
            ?>

                <h2>Nuevo Usuario</h2>
                <form action="<?= base_url('usuarios/saveusuario') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>


                    <!-- ESTO QUEDA ASI, CUANDO TERMINE TODO CAMBIAR EL REGISTRO A SOLO TRES CAMPOS
                        Y QUE ALLA UN EDITAR PARTIDO QUE ME HABILITE ESTE FORMULARIO -->

                    <!-- DNI -->
                    <div class="mb-3">
                        <label for="dniInput" class="form-label">DNI del Usuario</label>
                        <input type="text" name="dni" value="<?= set_value('dni') ?>" class="form-control" id="idDniInput" placeholder="DNI" required>
                    </div>

                    <!-- NOMBRE -->
                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Usuario</label>
                        <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>

                    <!-- APELLIDO -->
                    <div class="mb-3">
                        <label for="apellidoInput" class="form-label">Apellido del Usuario</label>
                        <input type="text" name="apellido" value="<?= set_value('apellido') ?>" class="form-control" id="idApellidoInput" placeholder="Apellido" required>
                    </div>

                    <!-- USUARIO -->
                    <div class="mb-3">
                        <label for="usuarioInput" class="form-label">Usuario</label>
                        <input type="text" name="usuario" value="<?= set_value('usuario') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>

                    <!-- CLAVE -->
                    <div class="mb-3">
                        <label for="claveInput" class="form-label">Clave</label>
                        <input type="password" name="clave" value="<?= set_value('clave') ?>" class="form-control" id="idClaveInput" placeholder="Ingrese una Clave" required>
                    </div>

                    <!-- REPETIR CLAVE  CAMBIAR ESTO PARA QUE SOLO VALIDE LA CLAVE!!!! -->
                    <div class="mb-3">
                        <label for="claveInput" class="form-label">Confrimar Clave</label>
                        <input type="password" name="clave2" value="" class="form-control" id="idClaveInput" placeholder="Ingrese una Clave" required>
                    </div>

                    <!-- EMAIL -->
                    <div class="mb-3">
                        <label for="emailInput" class="form-label">Email del Usuario</label>
                        <input type="text" name="email" value="<?= set_value('email') ?>" class="form-control" id="idEmailInput" placeholder="Email" required>
                    </div>

                    <!-- FECHA -->
                    <div class="mb-3">
                        <label for="fecha_nacInput" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" name="fecha_nac" value="<?= set_value('fecha_nac') ?>" class="form-control" id="idFecha_nacInput" placeholder="Fecha de Nacimiento" required>
                    </div>

                    <!-- ROL en el caso de un registro de participante se le deve asignar automaticamente el rol "PARTICIAPNTE" -->
                    <div class="mb-3">
                        
                        
                        <?php if (session()->rol == 'ADMIN'){  ?>

                        <label for="rolInput" class="form-label">Nombre del Usuario</label>
                        <!-- ACA PONER RADIO BUTTON PARA SELECIONAR "ADMIN" O "PARTICIPANTE" -->
                        <input type="text" name="rol" value="<?= set_value('rol') ?>" class="form-control" id="idNombreInput" placeholder="rol" required>
                        
                        <?php } ?>
                        
                        <input type="hidden" name="rol" value="PARTICIAPNTE">
                    </div>
                    

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <button type="reset" class="btn btn-secondary">Limpiar</button>


                    </div>

                </form>



            <?php } ?>

        </div>

        <?php if (session()->rol == 'ADMIN'){  ?>

        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <h2>Listado de Usuarios</h2>



            <table class="table table-striped table-primary text-center justify-content-center" id="usuarios-list">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>




                    <?php if (!empty($usuarios) && is_array($usuarios)) : ?>

                        <?php foreach ($usuarios as $usuarios_item) : ?>

                            <TR>
                                <TD><?= esc($usuarios_item['nombre']) ?></TD>


                                <td>
                                    <a href="<?= base_url('/usuarios') . '/' . esc($usuarios_item['id_usuarios'], 'url') ?>">
                                        <button class="btn btn-warning"><img src=<?= base_url('/img/iconoEditar.png') ?> alt="" class="iconos">
                                        </button>
                                    </a>
                                </td>





                                <td>
                                    <a href="<?= base_url('usuarios/bajausuario') . '/' . esc($usuarios_item['id_usuarios'], 'url') ?>">

                                        <button class="btn btn-danger">
                                            <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                        </button>
                                    </a>
                                </td>

                            </TR>







                        <?php endforeach ?>

                    <?php else : ?>

                        <h3>No hay usuarios</h3>

                        <p>No se encontraron usuarios</p>

                    <?php endif ?>



                </tbody>
            </table>
        </div>

        <?php } ?>

    </div>
</div>