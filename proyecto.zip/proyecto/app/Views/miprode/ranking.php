<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <!-- LISTAMOS LOS TORNEOS -->
        <?php if (!empty($torneos)) { ?>

            <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Torneos para ver el Ranking</h2>

            <table class="table table-striped table-primary text-center justify-content-center" id="equipos-list">
                <tbody>

                    <?php foreach ($torneos as $torneos_item) : ?>




                        <TR>
                            <TD><?= esc($torneos_item['nombre']) ?> -- Empieza el <?= esc($torneos_item['id_torneos']) ?>
                                -- Termina <?= esc($torneos_item['fecha_fin']) ?></TD>


                            <td>
                                <a href="<?= base_url('ranking/torneo') . '/' . esc($torneos_item['id_torneos'], 'url') ?>">
                                    <button type="button" class="btn btn-block btn-info">Ranking del Torneo</button>

                                </a>
                            </td>

                            <td>
                                <a href="<?= base_url('ranking/listarfases') . '/' . esc($torneos_item['id_torneos'], 'url') ?>">

                                    <button type="button" class="btn btn-block btn-info">Ranking de la Fase</button>
                                </a>
                            </td>

                        </TR>

                    <?php endforeach ?>
                </tbody>
            </table>




        <?php } else { ?>

            <!-- SE SELECCIONO RANKING POR FASES -> LISTAMOS LAS FASES -->
            <?php if (!empty($fases)) { ?>

                <?php //dd($fases); 
                ?>
                <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Fases del Torneo <?php echo ($torneo['nombre']); ?> para visualizar Ranking</h2>

                <?php if (!empty($fases) && is_array($fases)) : ?>

                    <?php foreach ($fases as $fases_item) : ?>


                        <div class="list-group">
                            <a href="<?= base_url('ranking/fases') . '/' . esc($fases_item['id_fases'], 'url') ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                                <?= esc($fases_item['nombre']) ?> -- Empieza el <?= esc($fases_item['fecha_ini']) ?>
                                -- Termina <?= esc($fases_item['fecha_fin']) ?>
                            </a>
                        </div>

                    <?php endforeach ?>

                    <!-- ACA PONER LO MISMO QUE EN LAS LISTAS PARA CUANDO NO HAY FASES -->
                <?php else : ?>

                    <h3>No hay fases</h3>

                    <p>No se encontraron fases</p>

                <?php endif ?>



            <?php } else { ?>

                <!-- SE SELECCIONO RANKING POR TORNEOS -> LISTAMOS RANKING  -->
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">

                    <?php if (!empty($fase)) { ?>

                        <h2 class="badge-light text-green text-center display-3 font-italic">Ranking del torneo <?php echo ($fase->nombreTorneo);
                                                                                                                ?> de la fase de <?php echo ($fase->nombre)
                                                                                                                                ?> </h2>


                    <?php } else { ?>

                        <h2 class="badge-light text-green text-center display-3 font-italic">Ranking del torneo <?php echo ($torneo['nombre']);
                                                                                                                ?> <?php //echo ($fase->nombre) 
                                                                                                                    ?> </h2>


                    <?php } ?>

                    <table class="table table-striped table-primary text-center justify-content-center" id="ranking-list">
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Puntos</th>
                                <!-- <th>Eliminar</th> -->
                            </tr>
                        </thead>
                        <tbody>




                            <?php if (!empty($puntos) && is_array($puntos)) : ?>

                                <?php foreach ($puntos as $puntos_item) : ?>

                                    <TR>
                                        <TD><?= esc($puntos_item->usuario) ?></TD>

                                        <TD><?= esc($puntos_item->puntos) ?></TD>

                                    </TR>

                                <?php endforeach ?>

                            <?php else : ?>

                                <h3>No hay puntajes</h3>

                                <p>No se encontraron puntajes</p>

                            <?php endif ?>

                        </tbody>
                    </table>


                </div>
                <!-- BOTON VOLVER FASES-->
                <?php if (!empty($fase)) { ?>
                    
                    <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">
                        <a href="<?= base_url('ranking/listarfases') . '/' . esc($fase->id_torneos, 'url')
                                    ?>" class="btn btn-secondary">Volver a Fases</a>
                    </div>

                <?php } ?>

            <?php } ?>

        <?php } ?>
        <!-- BOTON VOLVER TORNEOS-->
        <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">

            <a href="<?= base_url('/ranking') ?>" class="btn btn-secondary">Volver a Torneos</a>

        </div>


    </div>
</div>