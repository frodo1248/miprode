<h1 class="text-center my-5 py-5">Bienvenido a Mi Prode</h1>
<h1 class="text-center my-5 py-5">Ve a <a href="<?= base_url('/pronosticos') ?>"> Pronosticos</a> para emprezar a JUGAR</h1>
