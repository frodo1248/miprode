<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">



        <?php //dd($invitaciones); 
        ?>
        <!-- LISTAMOS LOS DESAFIOS -->
        <?php if (!empty($misinvitaciones)) { ?>

            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">

                <h2>Invitaciones Enviadas</h2>

                <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                    <thead>
                        <tr>
                            <th>Desafio</th>
                            <th>Invitado</th>
                            <th>Estado</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>




                        <?php if (!empty($misinvitaciones) && is_array($misinvitaciones)) : ?>

                            <?php foreach ($misinvitaciones as $invitaciones_item) : ?>

                                <TR>
                                    <!-- INVITADO -->
                                    <TD><?= esc($invitaciones_item->nombreDesafio) ?></TD>

                                    <!-- INVITADO -->
                                    <TD><?= esc($invitaciones_item->usuario) ?></TD>

                                    <!-- ESTADO -->
                                    <TD><?= esc($invitaciones_item->estado) ?></TD>


                                    <!-- ELIMINAR -->
                                    <?php if (esc($invitaciones_item->estado) == 'PENDIENTE') { ?>
                                        <td>
                                            <a href="<?= base_url('invitaciones/bajainvitacion') . '/' . esc($invitaciones_item->id_invitaciones, 'url') ?>">

                                                <button class="btn btn-danger">
                                                    <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                                </button>
                                            </a>
                                        </td>
                                    <?php } ?>

                                </TR>

                            <?php endforeach ?>

                        <?php else : ?>

                            <!-- <h3>No hay Fases</h3>

                            <p>No se encontraron Fases</p> -->

                            <h3>No se han realizado invitaciones</h3>

                        <?php endif ?>



                    </tbody>
                </table>
            </div>


        <?php } else { ?>


            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>

                <h2>Nueva Invitacion</h2>

                <form action="<?= base_url('invitaciones/saveinvitacion') ?>" method="post">
                    <!--usar base url-->
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>

                    <!-- USUARIO -->
                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre de Usuario</label>
                        <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Usuario" required>
                    </div>

                    <!-- ANFITRION -->
                    <div class="mb-3">
                        <input type="hidden" name="id_desafios" value="<?= esc($desafio['id_desafios']) ?> ?>">
                    </div>

                    <!-- BOTONES -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <button type="reset" class="btn btn-secondary">Limpiar</button>
                    </div>

                </form>



            </div>

            <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">

                <h2>Invitaciones del Desafio "<?= esc($desafio['nombre']) ?>"</h2>

                <table class="table table-striped table-primary text-center justify-content-center" id="torneos-list">
                    <thead>
                        <tr>
                            <th>Invitado</th>
                            <th>Estado</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>




                        <?php if (!empty($invitaciones) && is_array($invitaciones)) : ?>

                            <?php foreach ($invitaciones as $invitaciones_item) : ?>

                                <TR>
                                    <!-- INVITADO -->
                                    <TD><?= esc($invitaciones_item->usuario) ?></TD>

                                    <!-- ESTADO -->
                                    <TD><?= esc($invitaciones_item->estado) ?></TD>


                                    <!-- ELIMINAR -->
                                    <?php if (esc($invitaciones_item->estado) == 'PENDIENTE') { ?>
                                        <td>
                                            <a href="<?= base_url('invitaciones/bajainvitacion') . '/' . esc($invitaciones_item->id_invitaciones, 'url') ?>">

                                                <button class="btn btn-danger">
                                                    <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                                </button>
                                            </a>
                                        </td>
                                    <?php } ?>

                                </TR>

                            <?php endforeach ?>

                        <?php else : ?>

                            <!-- <h3>No hay Fases</h3>

                            <p>No se encontraron Fases</p> -->

                            <h3>No se han realizado invitaciones</h3>

                        <?php endif ?>



                    </tbody>
                </table>
            </div>


            <!-- BOTON VOLVER TORNEOS-->
            <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-4 py-4">

                <a href="<?= base_url('/desafios/misdesafios') ?>" class="btn btn-dark">Ir a Mis Desafios</a>

            </div>


        <?php } ?>

    </div>
</div>