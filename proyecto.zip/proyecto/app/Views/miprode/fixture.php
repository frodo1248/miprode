<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <!-- LISTAMOS LOS TORNEOS -->
        <?php if (!empty($torneos)) { ?>

            <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Torneos para ver su Fixture</h2>

            <?php foreach ($torneos as $torneos_item) : ?>


                <div class="list-group">
                    <a href="<?= base_url('fixture/mostrar') . '/' . esc($torneos_item->id_torneos) ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                        <?= esc($torneos_item->nombre) ?> -- Empieza el <?= esc($torneos_item->fecha_ini) ?>
                        -- Termina <?= esc($torneos_item->fecha_fin) ?>
                    </a>
                </div>

            <?php endforeach ?>


        <?php } else { ?>

            <!-- SE SELECCIONO UN TORNEO -> MOSTRAMOS SU FIXTURE -->

            <!-- PONER ACA EL NOMBRE DEL TORNEO -->


            <?php //dd($torneo) 
            ?>

            <?php if (!empty($torneo) && is_array($torneo)) : ?>


                <?php foreach ($torneo as $keyTorneo => $fases) {  ?>


                    <!--NOMBRE DEL TORNEO-->
                    <h2 class="badge-light text-green text-center display-3 font-italic"> <?php echo ($keyTorneo);
                                                                                            ?> </h2>



                    <?php

                    //echo($keyTorneo);//Nombre del torneo

                    foreach ($fases as $keyFases => $grupos) { ?>

                        <div class="col-sm-12 col-md-3 col-lg-3 col-xl-3">

                            <?php echo ($keyFases); //Nombre de las Fases 
                            ?>

                            <?php

                            //echo ($keyFases); //Nombre de las Fases

                            foreach ($grupos as $keyGrupos => $arregloPartidos) { ?>


                                <table class="table table-striped table-primary text-center" id="fixture-list">
                                    <thead>
                                        <tr>
                                            <th> <?php


                                                    echo ($keyGrupos); //Nombre de los Grupos
                                                    ?></th>
                                            <!-- <th>Editar</th>
                                    <th>Eliminar</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>


                                        <?php

                                        //echo ($keyGrupos); //Nombre de los Grupos


                                        foreach ($arregloPartidos as $key => $partidos) {

                                            foreach ($partidos as $item) { ?>



                                                <TR>
                                                    <TD>

                                                        <div>
                                                        <label for="flexCheckDefault">
                                                                <?php echo ($item->fecha_y_hora); //equipo local
                                                                ?>
                                                            </label>
                                                        </div>

                                                        <div>
                                                            <?php //dd($item->resultado); //equipo local
                                                            ?>
                                                            <input type="checkbox" id="flexCheckDefault" value="L" <?= $item->resultado == 'L' ? 'checked' : '' ?>>
                                                            <label for="flexCheckDefault">
                                                                <?php echo ($item->local); //equipo local
                                                                ?>
                                                            </label>
                                                            <input type="checkbox" id="flexCheckDefault" value="E" <?= $item->resultado == 'E' ? 'checked' : '' ?>>


                                                            <label for="flexCheckDefault">
                                                                <?php echo ($item->visitante); //equipo visitante 
                                                                ?>
                                                            </label>
                                                            <input type="checkbox" id="flexCheckDefault" value="V" <?= $item->resultado == 'V' ? 'checked' : '' ?>>
                                                        </div>



                                                    </TD>

                                                </TR>







                                            <?php } ?>
                                        <?php } ?>

                                    </tbody>
                                </table>

                            <?php } ?>

                        </div>

                    <?php } ?>




                <?php } ?>

                <?php //endforeach 
                ?>









            <?php else : ?>

                <h3>No hay partidos</h3>

                <p>No se encontraron partidos</p>

            <?php endif ?>





        <?php } ?>




    </div>
</div>