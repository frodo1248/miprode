<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

            <?= isset($validation) ? $validation->listErrors('my_list') : ""; ?>
            <?php

            if (!empty($equipo)) {


            ?>



                <h2>Modificar Equipo</h2>
                <form action="<?= base_url('equipos/saveequipo') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>

                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Equipo</label>
                        <input type="text" name="nombre" value="<?php echo $equipo['nombre'] ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required>
                    </div>



                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="<?= base_url('equipos') ?>" class="btn btn-secondary">Cancelar</a>

                        <input type="hidden" name="id_equipos" value="<?php echo $equipo['id_equipos']; ?>">
                        <!--Hace falta que le envie otro id para hacer el update, si no me crea otro registro-->

                      


                    </div>

                </form>


            <?php
            } else {
            ?>

                <h2>Nuevo Equipo</h2>
                <form action="<?= base_url('equipos/saveequipo') ?>" method="post">
                    <?= csrf_field() //genera en input hidden, esto me garantiza que 
                    //coincida ese valor y que no pueda hacer un post de otro lado 
                    ?>

                    <div class="mb-3">
                        <label for="nombreInput" class="form-label">Nombre del Equipo</label>
                        <input type="text" name="nombre" value="<?= set_value('nombre') ?>" class="form-control" id="idNombreInput" placeholder="Nombre" required autofocus>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <button type="reset" class="btn btn-secondary">Limpiar</button>


                    </div>

                </form>



            <?php } ?>

        </div>

        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <h2>Listado de Equipos</h2>


                <style> a{cursor: pointer;} </style> <!-- enviar a mi css personal, toca toda la pagina  -->
            <table class="table table-striped table-primary text-center justify-content-center" id="equipos-list">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>




                    <?php if (!empty($equipos) && is_array($equipos)) : ?>

                        <?php foreach ($equipos as $equipos_item) : ?>

                            <TR>
                                <TD><?= esc($equipos_item['nombre']) ?></TD>


                                <td>
                                    <a href="<?= base_url('/equipos') . '/' . esc($equipos_item['id_equipos'], 'url') ?>">
                                        <button class="btn btn-warning"><img src=<?= base_url('/img/iconoEditar.png') ?> alt="" class="iconos">
                                        </button>
                                    </a>
                                </td>





                                <td>
                                    <a href="<?= base_url('equipos/bajaequipo') . '/' . esc($equipos_item['id_equipos'], 'url') ?>">

                                        <button class="btn btn-danger">
                                            <img src=<?= base_url('/img/iconoEliminar.png') ?> alt="" class="iconos">

                                        </button>
                                    </a>
                                </td>

                            </TR>







                        <?php endforeach ?>

                    <?php else : ?>

                        <h3>No hay equipos</h3>

                        <p>No se encontraron equipos</p>

                    <?php endif ?>



                </tbody>
            </table>
        </div>


    </div>
</div>