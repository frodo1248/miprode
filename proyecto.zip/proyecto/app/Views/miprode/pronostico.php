<div class="container my-4 py-4 fondo-personalizado">

    <div class="row">

        <!-- LISTAMOS LOS TORNEOS -->
        <?php if (!empty($torneos)) { ?>

            <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Torneos para Pronosticar</h2>

            <?php foreach ($torneos as $torneos_item) : ?>


                <div class="list-group">
                    <a href="<?= base_url('pronosticos/listarfases') . '/' . esc($torneos_item->id_torneos) ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                        <?= esc($torneos_item->nombre) ?> -- Empieza el <?= esc($torneos_item->fecha_ini) ?>
                        -- Termina <?= esc($torneos_item->fecha_fin) ?>
                    </a>
                </div>

            <?php endforeach ?>


        <?php } else { ?>

            <!-- SE SELECCIONO UN TORNEO -> LISTAMOS LAS FASES -->
            <?php if (!empty($fases)) { ?>

                <?php //dd($fases); 
                ?>
                <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Fases del Torneo <?php echo ($torneo['nombre']); ?> para Pronosticar</h2>

                <?php foreach ($fases as $fases_item) : ?>


                    <div class="list-group">
                        <a href="<?= base_url('pronosticos/lista') . '/' . esc($fases_item['id_fases'], 'url') ?>" class="list-group-item list-group-item-action active my-2" aria-current="true">
                            <?= esc($fases_item['nombre']) ?> -- Empieza el <?= esc($fases_item['fecha_ini']) ?>
                            -- Termina <?= esc($fases_item['fecha_fin']) ?>
                        </a>
                    </div>

                <?php endforeach ?>



            <?php } else { ?>

                <!-- SI EL TORNEO NO TIENE FASES -->
                <?php if (empty($fase)) { ?>

                    <h2 class="badge-light text-green text-center display-3 font-italic">Este Torneo no tiene fases para pronosticar</h2>

                    <!-- SE SELECCIONO UNA FASE -> LISTAMOS LOS PARTIDOS -->
                <?php } else { ?>

                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <h2 class="badge-light text-green text-center display-3 font-italic">Listado de Partidos del Torneo <?php echo ($fase->nombreTorneo); ?> de la Fase de <?php echo ($fase->nombre) ?> para Pronosticar</h2>

                        <form action="<?= base_url('pronostico/savepronostico') ?>" method="post">

                            <?= csrf_field() ?>

                            <input type="hidden" name="id_fases" value="<?php echo $id_fases; ?>">

                            <table class="table table-striped table-primary text-center justify-content-center" id="partidosPronosticos-list">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Local</th>
                                        <?php if ($fase->es_eliminatoria == 0) { ?>
                                            <th>Empate</th>
                                        <?php } ?>
                                        <th>Visitante</th>

                                    </tr>
                                </thead>
                                <tbody>



                                    <?php if (!empty($partidos) && is_array($partidos)) : ?>

                                        <?php foreach ($partidos as $partidos_item) : ?>

                                            <TR>
                                                <!-- FECHA Y HORA -->
                                                <TD><?= date_format(new DateTime($partidos_item->fecha_y_hora), 'd F ') ?></TD>

                                                <!-- LOCAL --><!-- PREGUNTAR POR EL REQUIRED -->
                                                <TD>
                                                    <input type="radio" name="prono[<?= $partidos_item->id_partidos ?>][<?= $partidos_item->prono_id ?>]" value="L" <?= $partidos_item->prono == 'L' ? 'checked' : '' ?> required>
                                                    <?= $partidos_item->local ?>
                                                </TD>


                                                <?php if ($fase->es_eliminatoria == 0) { ?>
                                                    <!-- EMPATE -->
                                                    <TD>
                                                        <input type="radio" name="prono[<?= $partidos_item->id_partidos ?>][<?= $partidos_item->prono_id ?>]" value="E" <?= $partidos_item->prono == 'E' ? 'checked' : '' ?> required>
                                                        Empate
                                                    </TD>

                                                <?php } ?>

                                                <!-- VISITANTE -->
                                                <TD>
                                                    <input type="radio" name="prono[<?= $partidos_item->id_partidos ?>][<?= $partidos_item->prono_id ?>]" value="V" <?= $partidos_item->prono == 'V' ? 'checked' : '' ?> required>
                                                    <?= $partidos_item->visitante ?>
                                                </TD>


                                            </TR>


                                        <?php endforeach ?>


                                    <?php else : ?>

                                        <h3>No hay partidos para pronosticar</h3>

                                        <p>No se encontraron partidos para pronosticar</p>

                                    <?php endif ?>



                                </tbody>
                            </table>
                            <!-- BOTONES -->
                            <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2">
                                <button type="submit" class="btn btn-success">Guardar mis Pronosticos</button>

                            </div>

                        </form>

                    </div>
                    <!-- BOTON VOLVER FASES-->
                    <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">

                        <a href="<?= base_url('pronosticos/listarfases') . '/' . esc($fase->id_torneos, 'url') ?>" class="btn btn-secondary">Volver a Fases</a>

                    </div>
                <?php } ?>

            <?php } ?>
            <!-- BOTON VOLVER TORNEOS-->
            <div class="d-grid gap-2 col-sm-12 col-md-4 col-lg-4 col-xl-4 my-2 py-2 mx-2">

                <a href="<?= base_url('/pronosticos') ?>" class="btn btn-secondary">Volver a Torneos</a>

            </div>
        <?php } ?>


    </div>
</div>