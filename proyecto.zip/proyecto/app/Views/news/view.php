<h2><?= esc($news['title']) ?></h2>
<p><?= esc($news['body']) ?></p>