<?php
 echo 'Felicitaciones se ha '. $accion . ' el articulo';
?>