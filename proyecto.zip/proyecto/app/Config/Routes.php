<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.


//$routes->get('/', 'Equipos::index'); //aca va mi pagina principal

//HOME principal
$routes->get('home', 'Home::index');

//LOGIN principal
$routes->get('/', 'Login::index');
//LOGIN logueo
//$routes->post('/(:any)', 'Login::logeo/$1');

$routes->match(['get', 'post'], 'login', 'Login::logeo');

//LOGEO Cerrar Sesion
$routes->get('cerrarsesion', 'Login::cerrarSesion');


//EQUIPOS principal
$routes->get('equipos', 'Equipos::index');
//EQUIPO Alta Equipo
$routes->match(['get', 'post'], 'equipos/saveequipo', 'Equipos::saveEquipo');
//EQUIPO Baja Equipo
$routes->get('equipos/bajaequipo/(:any)', 'Equipos::bajaEquipo/$1');
//EQUIPO Modificar Equipo
$routes->get('equipos/(:any)', 'Equipos::view/$1');

//$routes->match(['get', 'post'], 'equipos/saveequipo', 'Equipos::saveEquipo');
//$routes->get('modificarequipo/(:any)', 'Equipos::nuevoEquipo');


//TORNEOS principal
$routes->get('torneos', 'Torneos::index');
//TORNEOS Alta Torneo
$routes->match(['get', 'post'], 'torneos/savetorneo', 'Torneos::saveTorneo');
//TORNEOS Baja Torneo
$routes->get('torneos/bajatorneo/(:any)', 'Torneos::bajaTorneo/$1');
//TORNEOS Modificar Torneo
$routes->get('torneos/(:any)', 'Torneos::view/$1');

//$routes->match(['get', 'post'], 'torneos/savetorneo', 'Torneos::saveTorneo');


//FASES principal
$routes->get('fases', 'Fases::index');
$routes->get('fases/mostrarfase/(:any)', 'Fases::mostrarFase/$1');
//FASES Alta Fases
$routes->match(['get', 'post'], 'fases/savefase', 'Fases::saveFase');
//FASES Baja Fases
$routes->get('fases/bajafase/(:any)', 'Fases::bajaFase/$1');
//FASES Modificar Fases
$routes->get('fases/(:any)', 'Fases::view/$1');

//$routes->match(['get', 'post'], 'fases/savefase', 'Fases::saveFase');


//PARTIDOS principal
//$routes->get('partidos', 'Partidos::index');
$routes->get('partidos/', 'Partidos::listaTorneos/$1');
$routes->get('partidos/listarfasespartidos/(:any)', 'Partidos::listarFasesPartidos/$1');
$routes->get('partidos/listapartidos/(:any)', 'Partidos::listaPartidos/$1');
//PARTIDOS Alta Partidos
$routes->match(['get', 'post'], 'partidos/savepartido', 'Partidos::savePartido');

//PARTIDOS Resultados
$routes->get('partidos/resultados', 'Partidos::listaTorneos');
$routes->get('partidos/listarfases/(:any)', 'Partidos::listarFases/$1');
$routes->get('partidos/lista/(:any)', 'Partidos::lista/$1');
//PARTIDOS Alta resultados
$routes->match(['get', 'post'], 'partidos/saveresultado', 'Partidos::saveResultado');

//PARTIDOS Baja Partidos
$routes->get('partidos/bajapartido/(:any)', 'Partidos::bajaPartido/$1');
//PARTIDOS Modificar Partidos
$routes->get('partidos/(:any)', 'Partidos::view/$1');
//$routes->match(['get', 'post'], 'partidos/savepartido', 'Partidos::savePartido');




//PRONOSTICOS principal
$routes->get('pronosticos', 'Pronosticos::index');
$routes->get('pronosticos/listarfases/(:any)', 'Pronosticos::listarFases/$1');
$routes->get('pronosticos/lista/(:any)', 'Pronosticos::lista/$1');


//PRONOSTICOS Alta Pronosticos
$routes->match(['get', 'post'], 'pronostico/savepronostico', 'Pronosticos::savePronostico');

//PRONOSTICOS Baja Pronosticos
//$routes->get('bajapronostico/(:any)', 'Pronosticos::bajaPartido/$1');
//PRONOSTICOS Modificar Pronosticos
//$routes->get('pronosticos/(:any)', 'Pronosticos::view/$1');

//$routes->match(['get', 'post'], 'pronosticos/savepronostico', 'Pronosticos::savePronostico');


//USUARIOS Alta Usuarios
$routes->get('usuarios/index', 'Usuarios::indexParticipante');
$routes->get('usuariosnuevos/index', 'Usuarios::indexParticipante');

$routes->match(['get', 'post'], 'usuarios/saveusuario', 'Usuarios::saveUsuario');


//RANKING principal
$routes->get('ranking', 'Ranking::index');
// RANKING por Torneos
$routes->get('ranking/torneo/(:any)', 'Ranking::torneo/$1');
// RANKING por Fases
$routes->get('ranking/listarfases/(:any)', 'Ranking::listarFases/$1');

$routes->get('ranking/fases/(:any)', 'Ranking::fases/$1');

// //RANKING Modificar Fases
// $routes->get('fases/(:any)', 'Fases::view/$1');

// $routes->match(['get', 'post'], 'fases/savefase', 'Fases::saveFase');

// FIXTURE principal
$routes->get('fixture', 'Fixture::index');
// FIXTURE mostrar fixture de un torneo
$routes->get('fixture/mostrar/(:any)', 'Fixture::mostrar/$1');


//DESAFIOS principal
$routes->get('desafios', 'Desafios::index');
$routes->get('desafios/creardesafio/(:any)', 'Desafios::altaDesafio/$1');
//DESAFIOS alta desafio
$routes->match(['get', 'post'], 'desafios/savedesafio', 'Desafios::saveDesafio');
//DESAFIOS Mis Desafios
$routes->get('desafios/misdesafios', 'Desafios::misDesafios');
// $routes->match(['get', 'post'], 'equipos/saveequipo', 'Equipos::saveEquipo');


//INVITACIONES principal
$routes->get('invitacion', 'Invitaciones::index');
$routes->get('invitaciones/crearinvitacion/(:any)', 'Invitaciones::crearInvitacion/$1');
//INVITACIONES alta invitacion
$routes->match(['get', 'post'], 'invitaciones/saveinvitacion', 'Invitaciones::saveInvitacion');
//INVITACIONES baja invitacion
$routes->get('invitaciones/bajainvitacion/(:any)', 'Invitaciones::bajaInvitacion/$1');



// //EQUIPO Baja Equipo
// $routes->get('equipos/bajaequipo/(:any)', 'Equipos::bajaEquipo/$1');
// //EQUIPO Modificar Equipo
// $routes->get('equipos/(:any)', 'Equipos::view/$1');





//Ejemplo News
$routes->get('news', 'News::index');
$routes->match(['get', 'post'], 'news/create', 'News::create');
$routes->get('news/delete/(:any)', 'News::delete/$1');
// $routes->get('news/(:segment)', 'News::view/$1');

//Routes Iniciales
// $routes->get('pages', 'Pages::index');
// $routes->get('(:any)', 'Pages::view/$1');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
