<?php

namespace App\Models;

use CodeIgniter\Model;

class PartidosModel extends Model
{
    protected $table      = 'partidos';
    protected $primaryKey = 'id_partidos';

    // protected $useAutoIncrement = true;

    // protected $returnType     = 'array';
    // protected $useSoftDeletes = false; #hay que dejarlo en falso dice leo mercado, por que tira error

    protected $allowedFields = ['id_partidos', 'fecha_y_hora', 'resultado', 'fases_id_fases', 'grupos_id_grupos', 'equipos_id_equipos_local', 'equipos_id_equipos_visitante'];


    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // protected $validationRules    = [];
    // protected $validationMessages = [];
    // protected $skipValidation     = false;


    public function getPartidos($id_partidos = false)
    {
        if ($id_partidos === false) {
            return $this->findAll();
        }
        //dd($id_partidos);
        return $this->where(['id_partidos' => $id_partidos])->first();
    }

    public function getResultado($id_partidos = false)
    {
        if ($id_partidos === false) {
            $query = $this->db->query("select p.resultado from partidos p where p.id_partidos = $id_partidos");

            $resultado = $query->getRow(0);


            return $resultado;
        }
    }

    public function getPartidosConGrupos($id_partidos = false)
    {
        $query = $this->db->query('select f.*, t.* from fases f left join torneos t on (f.torneos_id_torneos = t.id_torneos)');

        $resultado = $query->getResult(); // preguntar si esto es realmente util 
        //por que de todo modos tengo que traer grupos para el alta de partidos

        return $resultado;
    }

    public function findByAndFase($fase_id)
    {


        // $builder = $this->db->table('partidos p');

        // $builder->select('p.*, ev.nombre visitante, 
        // el.nombre local,pr.id_pronosticos prono_id, pr.resultado_previsto prono, pr.usuarios_id_usuarios')
        // ->join('equipos ev', 'p.equipos_id_equipos_visitante = ev.id_equipos','LEFT')
        // ->join('equipos el', 'p.equipos_id_equipos_local = el.id_equipos','LEFT')
        // ->join('pronosticos pr', 'p.id_partidos = pr.partidos_id_partidos','LEFT')
        // ->where('p.fases_id_fases', $fase_id)//no me filtra las fases

        // ->where("pr.usuarios_id_usuarios = $user_id OR pr.usuarios_id_usuarios is NULL");



        // $results = $builder->get()->getCustomResultObject(PartidosModel::class);


        $query = $this->db->query("SELECT p.*, ev.nombre visitante, el.nombre as local
                                    FROM  partidos p left join equipos ev on (p.equipos_id_equipos_visitante = ev.id_equipos) LEFT join equipos el on (p.equipos_id_equipos_local = el.id_equipos)
                                    WHERE (p.fases_id_fases = $fase_id)");

        $resultado = $query->getResult();


        return $resultado;
    }


    public function fixture($id_torneo = null){

        $query = $this->db->query("select t.id_torneos, t.nombre as nombreTorneo, 
        f.id_fases, f.nombre as nombreFase, 
        p.id_partidos, p.fecha_y_hora, el.nombre as local, ev.nombre visitante, p.resultado,
        g.nombre as nombreGrupo
        from torneos t right join fases f on (t.id_torneos=f.torneos_id_torneos) 
        join partidos p on (p.fases_id_fases = f.id_fases)
        join grupos g on (g.id_grupos = p.grupos_id_grupos)
        join equipos el on (el.id_equipos = p.equipos_id_equipos_local)
        join equipos ev on (ev.id_equipos = p.equipos_id_equipos_visitante)
        where t.id_torneos=$id_torneo 
        order by f.id_fases,nombreGrupo;
        ");

        $resultado = $query->getResult();


        return $resultado;

    }

}
