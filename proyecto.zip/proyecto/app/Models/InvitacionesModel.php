<?php

namespace App\Models;

use CodeIgniter\Model;

class InvitacionesModel extends Model
{
    protected $table      = 'invitaciones';
    protected $primaryKey = 'id_invitaciones';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['id_desafios', 'id_invitado', 'id_anfitrion'];


    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


    public function getInvitaciones($id_invitaciones = false)
    {
        if ($id_invitaciones === false) {
            return $this->findAll();
        }
        //dd($id_invitaciones);
        return $this->where(['id_invitaciones' => $id_invitaciones])->first();
    }


    public function getMisInvitaciones($id_invitaciones = false)
    {
        $query = $this->db->query("SELECT i.*, u.usuario, d.nombre as nombreDesafio

        FROM invitaciones i join usuarios u on ( i.id_invitado = u.id_usuarios) 
        join desafios d on (i.id_desafios = d.id_desafios) 
        order by 1;");



        $resultado = $query->getResult();

        return $resultado;
    }


    
}
