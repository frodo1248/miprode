<?php

namespace App\Models;

use CodeIgniter\Model;

class TorneosModel extends Model
{
    protected $table      = 'torneos';
    protected $primaryKey = 'id_torneos';

    // protected $useAutoIncrement = true;

    // protected $returnType     = 'array';
    // protected $useSoftDeletes = false; #hay que dejarlo en falso dice leo mercado, por que tira error

    protected $allowedFields = ['id_torneos', 'nombre', 'fecha_ini', 'fecha_fin'];


    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // protected $validationRules    = [];
    // protected $validationMessages = [];
    // protected $skipValidation     = false;


    public function getTorneos($id_torneos = false)
    {
        if ($id_torneos === false) {
            return $this->findAll();
        }
        //dd($id_torneos);
        return $this->where(['id_torneos' => $id_torneos])->first();
    }

    // public function getTorneosActivos()
    // {
    //     $query = $this->db->query("select t.* from torneos t where t.fecha_fin > now();");

    //     return $resultado = $query->getResult();

    //     //dd($id_torneos);
    //     return $resultado;
    // }

    public function getTorneosPronosticos($id_torneos = false)
    {
        if ($id_torneos === false) {
            $query = $this->db->query("select t.* from torneos t where t.fecha_fin > now();");



            return $resultado = $query->getResult();
        }
        //dd($id_torneos);
        return $this->where(['id_torneos' => $id_torneos])->first();
    }

    public function getTorneosPronosticosTodos($id_torneos = false)
    {
        if ($id_torneos === false) {
            $query = $this->db->query("select t.* from torneos t;");



            return $resultado = $query->getResult();
        }
        //dd($id_torneos);
        return $this->where(['id_torneos' => $id_torneos])->first();
    }
}
