<?php

namespace App\Models;

use CodeIgniter\Model;

class GruposModel extends Model
{
    protected $table      = 'grupos';
    protected $primaryKey = 'id_grupos';

    // protected $useAutoIncrement = true;

    // protected $returnType     = 'array';
    // protected $useSoftDeletes = false; #hay que dejarlo en falso dice leo mercado, por que tira error

    protected $allowedFields = ['id_grupos', 'nombre']; 
    

    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // protected $validationRules    = [];
    // protected $validationMessages = [];
    // protected $skipValidation     = false;


    public function getGrupos($id_grupos = false)
    {
        if ($id_grupos === false) {
            return $this->findAll();
        }
        //dd($id_grupos);
        return $this->where(['id_grupos' => $id_grupos])->first();
    }
    
    public function getGruposTorneo($id_torneos = false)
    {
        
        $query = $this->db->query("");

        $resultado = $query->getResult();


        return $resultado;
    }

}