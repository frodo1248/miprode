<?php

namespace App\Models;

use CodeIgniter\Model;

class FasesModel extends Model
{
    protected $table      = 'fases';
    protected $primaryKey = 'id_fases';

    // protected $useAutoIncrement = true;

    // protected $returnType     = 'array';
    // protected $useSoftDeletes = false; #hay que dejarlo en falso dice leo mercado, por que tira error

    protected $allowedFields = ['id_fases', 'nombre', 'fecha_ini', 'fecha_fin', 'torneos_id_torneos', 'es_eliminatoria']; 
    

    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // protected $validationRules    = [];
    // protected $validationMessages = [];
    // protected $skipValidation     = false;


    public function getFases($id_fases = false)
    {
        if ($id_fases === false) {
            return $this->findAll();
        }
        //dd($id_fases);
        return $this->where(['id_fases' => $id_fases])->first();
    }

    public function getFasesTorneo($id_torneos = false)
    {
        
        //dd($id_torneos);
        return $this->where(['torneos_id_torneos' => $id_torneos])->findAll();
    }

    public function getFase($id_fases = false){
        if ($id_fases === false) {
            return $this->findAll();
        }

        $query = $this->db->query("select f.*, t.id_torneos, t.nombre as nombreTorneo, t.fecha_ini, t.fecha_fin from fases f left join torneos t on (f.torneos_id_torneos = t.id_torneos) where f.id_fases = $id_fases");
       
        $resultado = $query->getRow(0); 

        return $resultado;
    }

}