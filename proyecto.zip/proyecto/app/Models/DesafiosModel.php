<?php

namespace App\Models;

use CodeIgniter\Model;

class DesafiosModel extends Model
{
    protected $table      = 'desafios';
    protected $primaryKey = 'id_desafios';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['id_desafios', 'nombre', 'id_usuarios', 'id_torneos'];


    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


    public function getDesafios($id_desafios = false)
    {
        if ($id_desafios === false) {
            return $this->findAll();
        }
        //dd($id_desafios);
        return $this->where(['id_desafios' => $id_desafios])->first();
    }


    public function getMisDesafios($id_desafios = false)
    {
        $query = $this->db->query("SELECT d.*, t.nombre as nombreTorneo

        FROM desafios d join torneos t on ( d.id_torneos = t.id_torneos) 
        order by 1;");



        $resultado = $query->getResult();

        return $resultado;
    }
}
