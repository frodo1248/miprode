<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuariosModel extends Model
{
    protected $table      = 'usuarios';
    protected $primaryKey = 'id_usuarios';

    // protected $useAutoIncrement = true;

    // protected $returnType     = 'array';
    // protected $useSoftDeletes = false; #hay que dejarlo en falso dice leo mercado, por que tira error

    protected $allowedFields = ['id_usuarios', 'dni' , 'nombre', 'apellido', 'usuario', 'clave', 'email', 'fecha_nac', 'rol']; 
    

    // protected $useTimestamps = false;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // protected $validationRules    = [];
    // protected $validationMessages = [];
    // protected $skipValidation     = false;


    public function getUsuarios($id_usuarios = false)
    {
        if ($id_usuarios === false) {
            return $this->findAll();
        }
        //dd($id_usuarios);
        return $this->where(['id_usuarios' => $id_usuarios])->first();
    }


    public function loginUsuario($usuario = false){
        
        if ($this->where(['usuario' => $usuario])->first()) {
            return $this->where(['usuario' => $usuario])->first();
        }

        return null;
    }


    public function getId($usuario = false)
    {
        if ($usuario === false) {
            return $this->findAll();
        }
        //dd($id_usuarios);
        return $this->where(['usuario' => $usuario])->first();
    }


}