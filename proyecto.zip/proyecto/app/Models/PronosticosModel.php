<?php

namespace App\Models;

use CodeIgniter\Model;

class PronosticosModel extends Model
{
    protected $table      = 'pronosticos';
    protected $primaryKey = 'id_pronosticos';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['resultado_previsto', 'partidos_id_partidos', 'fecha', 'usuarios_id_usuarios'];

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;



    public function findByUserAndFase($user_id, $fase_id)
    {


        // $builder = $this->db->table('partidos p');

        // $builder->select('p.*, ev.nombre visitante, 
        // el.nombre local,pr.id_pronosticos prono_id, pr.resultado_previsto prono, pr.usuarios_id_usuarios')
        // ->join('equipos ev', 'p.equipos_id_equipos_visitante = ev.id_equipos','LEFT')
        // ->join('equipos el', 'p.equipos_id_equipos_local = el.id_equipos','LEFT')
        // ->join('pronosticos pr', 'p.id_partidos = pr.partidos_id_partidos','LEFT')
        // ->where('p.fases_id_fases', $fase_id)//no me filtra las fases

        // ->where("pr.usuarios_id_usuarios = $user_id OR pr.usuarios_id_usuarios is NULL");



        // $results = $builder->get()->getCustomResultObject(PartidosModel::class);


        $query = $this->db->query("SELECT p.*, el.nombre as local, ev.nombre visitante,  
                                    (select pr.resultado_previsto from pronosticos pr where pr.partidos_id_partidos = p.id_partidos and pr.usuarios_id_usuarios = $user_id) prono,
                                    (select pr.id_pronosticos from pronosticos pr where pr.partidos_id_partidos = p.id_partidos and pr.usuarios_id_usuarios = $user_id)  prono_id

                                    FROM partidos p left join equipos el on ( p.equipos_id_equipos_local = el.id_equipos) 
                                    join equipos ev on (p.equipos_id_equipos_visitante = ev.id_equipos)
                                    where p.fases_id_fases = $fase_id
                                    order by 1;");



        $resultado = $query->getResult();


        //dd($resultado);

        return $resultado;
    }

    public function getPronosticos($id_pronosticos = false)
    {
        if ($id_pronosticos === false) {
            return $this->findAll();
        }
        //dd($id_pronosticos);
        return $this->where(['id_pronosticos' => $id_pronosticos])->first();
    }

    public function puntos($id_torneos = null)
    {

        $query = $this->db->query("select u.usuario, puntos($id_torneos, u.id_usuarios) as puntos
        from usuarios u order by  puntos desc;");

        $resultado = $query->getResult();

        //dd($resultado);
        return $resultado;
    }

    public function puntosFase($id_fases = null)
    {

        $query = $this->db->query("select u.usuario, puntosFase($id_fases, u.id_usuarios) as puntos
        from usuarios u order by  puntos desc;");

        $resultado = $query->getResult();

        //dd($resultado);
        return $resultado;
    }
}
