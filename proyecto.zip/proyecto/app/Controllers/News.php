<?php

namespace App\Controllers;

use App\Models\NewsModel;

class News extends BaseController
{
    public function index()
    {
        $model = model(NewsModel::class);

        $data = [
            'news'  => $model->getNews(),
            'title' => 'News archive',
        ];

        return view('templates/header', $data)
            . view('templates/nav')
            . view('news/overview')
            . view('templates/footer');
    }

    public function view($slug = null)
    {
        $model = model(NewsModel::class);

        $data['news'] = $model->getNews($slug);

        if (empty($data['news'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Cannot find the news item: ' . $slug);
        }

        $data['title'] = $data['news']['title'];

        return view('templates/header', $data)
            . view('news/view')
            . view('templates/footer');
    }


    public function create()
    {
        $model = model(NewsModel::class);

        if ($this->request->getMethod() === 'post' && $this->validate([
            'title' => 'required|min_length[3]|max_length[255]',
            'body'  => 'required',
        ])) { //se puede poner en español el mensaje, ver el validate
            $model->save([
                'title' => $this->request->getPost('title'),
                'slug'  => url_title($this->request->getPost('title'), '-', true),
                'body'  => $this->request->getPost('body'),
            ]);
            //url_title saca los espacios y le pone guion, y todo en minuscula

            $data['accion'] = 'agregado';

            return view('news/success', $data);
        }

        return view('templates/header', ['title' => 'Create a news item'])
            . view('templates/nav')
            . view('news/create')
            . view('templates/footer');
    }

    public function delete($slug = null)
    {
        $model = model(NewsModel::class);

        $model->where('slug', $slug)->delete();

        $data['accion'] = 'eliminado'; //aca usar flash data

        return view('news/success', $data);
    }

    public function update($slug = null)
    {
        $model = model(NewsModel::class);

        $model->where('slug', $slug)->delete();

        $data['accion'] = 'actualizado';

        return view('news/success', $data);
    }
}
