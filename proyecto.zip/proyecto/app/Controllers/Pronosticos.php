<?php

namespace App\Controllers;

use App\Models\PartidosModel;
use App\Models\FasesModel;
use App\Models\TorneosModel;
use App\Models\EquiposModel;
use App\Models\GruposModel;
use App\Models\PronosticosModel;
use Config\Services;

class Pronosticos extends BaseController
{

    protected $helpers = ['form'];
    public $page = 'pronostico';

    public function index()
    {

        $modelTorneos = model(TorneosModel::class);

        $data = [
            'torneos'  => $modelTorneos->getTorneosPronosticos(),
        ];

        //dd($data);
        return $this->mostrarAdmin($this->page, $data);
    }

    public function listarFases($id_torneos = null)
    {


        //TORNEO
        $modelTorneos = model(TorneosModel::class);
        $torneo = $modelTorneos->getTorneos($id_torneos);

        //FASES
        $modelFases = model(FasesModel::class);

        //dd($torneo);

        $data = [
            'fases'  => $modelFases->getFasesTorneo($id_torneos),
            'torneo' => $torneo //esto lo hice recien para el volver Fases
        ];


        return $this->mostrarAdmin($this->page, $data);
    }



    public function lista($id_fases = null)
    {


        $id_usuario = session()->id_usuarios;
        //dd($id_usuario);

        //FASES
        $modelFases = new FasesModel();
        $fase = $modelFases->getFase($id_fases);

        //dd($fase);
        //PRONOSTICOS
        $model = new PronosticosModel();
        $items = $model->findByUserAndFase($id_usuario, $id_fases);

        //dd($items);
        $data = array(
            'partidos' => $items,
            'usuario' => $id_usuario,
            'id_fases' => $id_fases,
            'fase' => $fase
        );



        //return $this->response->redirect(base_url("pronosticos/lista/$id_fases"));
        return $this->mostrarAdmin($this->page, $data);
    }



    public function savePronostico($nombre = null)
    {

        $pronosticos = $this->request->getPost('prono');

        $prono = new PronosticosModel();

        $id_usuario = session()->id_usuarios;

        if (!empty($pronosticos)) {
            foreach ($pronosticos as $key => $value) {
                $partido_id = $key;
                foreach ($value as $key => $value) {
                    $prono->save([
                        'id_pronosticos' => $key ? $key : null,
                        'resultado_previsto' => $value,
                        'partidos_id_partidos' => $partido_id,
                        'fecha' => date('Y-m-d'),
                        'usuarios_id_usuarios' => $id_usuario
                    ]);
                }
            }
        }



        $idfase = $this->request->getPost('id_fases');

        //dd($idfase);

        //FASES
        $modelFases = new FasesModel();
        $fase = $modelFases->getFase($idfase);
        //dd($fase);

        //dd($fase);
        //PRONOSTICOS
        $model = new PronosticosModel();
        $items = $model->findByUserAndFase($id_usuario, $idfase);

        $data = array(
            'partidos' => $items,
            'usuario' => $id_usuario,
            'id_fases' => $idfase,
            'fase' => $fase
        );

        return $this->response->redirect(base_url("pronosticos/lista/$idfase"));
        //return $this->mostrarAdmin($this->page, $data);
    }








    public function view($id_partidos = null)
    {
        $model = model(PartidosModel::class);
        $modelFases = model(FasesModel::class);
        $modelEquipos = model(EquiposModel::class);
        $modelGrupos = model(GruposModel::class);


        $data = [
            'partidos'  => $model->getPartidos(),
            'partido' => $model->getPartidos($id_partidos)
        ];


        $data['fases']  =  $modelFases->getFases();

        $data['equipos']  =  $modelEquipos->getEquipos();

        $data['grupos']  =  $modelGrupos->getGrupos();

        if (empty($data['partidos'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el partido: ' . $id_partidos);
        }



        return $this->mostrarAdmin($this->page, $data);
        // return view('templates/header', $data)
        //     . view('templates/navbar')
        //     . view('templates/sidebar')
        //     . view('miprode/partido')
        //     . view('templates/footer');
    }
}



// $pronostico = $this-> request->getPost('prono');

// $prono = new Pronostico();

// //Esto sirve pero no tiene una buena performance
// foreach ($pronostico as $key => $value){
//     $partido_id = $key;
//     foreach ($value as $key => $value){
//     $prono->save([
//         'id' => $key ? $key : null,
//         'partido_id' => $partido_id,
//         'prono' => $value,
//         'usuario_id' => session()->user_id

//         ]);
//     }

   
// }
// reuturn $this->redirect()->to('base_url(pronosticos/view'));//ver usar el mio

// //Para editar los pronosticos
// public view(deberia recibir usuario y fase){

//     $itema = $model->fuindUserFace();

// }


// //esto es en el modelo
// public fuctin findUserFase($user, $face){

//     $builder = $this->db->table('partidos p');

//     &builder->select('consulta sql de los partidos trallendo los equipos local y visitante y el pronostico de equipos_id_equipos_local
    
// -->join('equipos ev', 'pvisitante_id')

//     debo hacer un where --> 'p.fase_id', $fase_id
// }y where --> 'pr.usuario_id', $user_id)


//     results = $builder->get()->getCustomResultObjects(Pronostico::Class);

//     return $results
// }