<?php

namespace App\Controllers;

use App\Models\PartidosModel;
use App\Models\FasesModel;
use App\Models\EquiposModel;
use App\Models\GruposModel;
use Config\Services;

class Partidos extends BaseController
{

    protected $helpers = ['form'];
    public $page = 'partido';
    public $pageResultado = 'resultado';
    public $pageListarPartidos = 'listarpartidos';

    public function index()
    {
        $model = model(PartidosModel::class);
        $modelFases = model(FasesModel::class);
        $modelEquipos = model(EquiposModel::class);
        $modelGrupos = model(GruposModel::class);

        $data = [
            'partidos'  => $model->getPartidos(),
            'title' => 'Partidos'
        ];
        //$page = 'partido';

        $data['fases']  =  $modelFases->getFases();

        $data['equipos']  =  $modelEquipos->getEquipos();

        $data['grupos']  =  $modelGrupos->getGrupos();


        return $this->mostrarAdmin($this->page, $data);
        // return view('templates/header', $data)
        //     . view('templates/navbar')
        //     . view('templates/sidebar')
        //     //. view('templates/nav')
        //     . view('miprode/partido')
        //     . view('templates/footer');
    }

    public function view($id_partidos = null)
    {
        //$model = model(PartidosModel::class);
        $model = new PartidosModel();
        $modelFases = model(FasesModel::class);
        $modelEquipos = model(EquiposModel::class);
        $modelGrupos = model(GruposModel::class);

        $partido = $model->getPartidos($id_partidos);

        //dd($partido);
        $id_fase = $partido['fases_id_fases'];
        //dd($id_fase);
        $partidos = $model->findByAndFase($id_fase);

        $data = array(
            'partidos'  => $partidos,
            'partido' => $partido
        );


        //asdasd
        // LISTAR DEL ABM PARTIDOS
        // public function listaPartidos($id_fases = null)
        // {

        //     //FASES
        //     $modelFases = new FasesModel();
        //     $fase = $modelFases->getFase($id_fases);

        //     //dd($fase);
        //     //PRONOSTICOS
        //     $model = new PartidosModel();
        //     $partidos = $model->findByAndFase($id_fases);

        //     //dd($items);
        //     $data = array(
        //         'partidos' => $items,
        //         'id_fases' => $id_fases,
        //         'fase' => $fase
        //     );

        //     //EQUIPOS
        //     $modelEquipos = new EquiposModel();
        //     $data['equipos']  =  $modelEquipos->getEquipos();

        //     //GRUPOS
        //     $modelGrupos = new GruposModel();
        //     $data['grupos']  =  $modelGrupos->getGrupos();

        //     return $this->mostrarAdmin($this->page, $data);
        // }

        //asdasd




        //$idfase = ;
        $data['fase'] = $modelFases->getFase($id_fase);
        //dd( $data['fase']);
        //$data['fases']  =  $modelFases->getFases($partido->fases_id_fases);

        $data['equipos']  =  $modelEquipos->getEquipos();

        $data['grupos']  =  $modelGrupos->getGrupos();

        if (empty($data['partidos'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el partido: ' . $id_partidos);
        }



        return $this->mostrarAdmin($this->page, $data);
        // return view('templates/header', $data)
        //     . view('templates/navbar')
        //     . view('templates/sidebar')
        //     . view('miprode/partido')
        //     . view('templates/footer');
    }


    public function savePartido($nombre = null)
    {
        $model = model(PartidosModel::class);

        $data['partidos'] = $model->getPartidos();

        $data['validation']  = Services::validation();

        $mensaje['error'] = 'Ya existe ese partido en la BD';

        $id_fase = $this->request->getPost('fases_id_fases');
        $id_partidos = $this->request->getPost('id_partidos');

        //NO SE TIENE QUE PODER EDITAR UN PARTIDO QUE TENGA EL RESULTADO PUESTO

        if ($this->request->getMethod() === 'post' && $this->validate([
            'fecha_y_hora' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe ese partido en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]


            ]
        ])) { //se puede poner en español el mensaje, ver el validate

            //dd($this->request->getPost('id_partidos'));
            $model->save([
                'id_partidos' => $this->request->getPost('id_partidos'),
                'fecha_y_hora' => $this->request->getPost('fecha_y_hora'),
                'resultado' => $this->request->getPost('resultado'),
                'fases_id_fases' => $this->request->getPost('fases_id_fases'),
                'grupos_id_grupos' => $this->request->getPost('grupos_id_grupos'),
                'equipos_id_equipos_local' => $this->request->getPost('equipos_id_equipos_local'),
                'equipos_id_equipos_visitante' => $this->request->getPost('equipos_id_equipos_visitante'),

            ]);


            return $this->response->redirect(base_url("/partidos/listapartidos/$id_fase"));
        }



        //return redirect()->to(base_url("/partidos/$id_partidos"))->with('mensaje', 'Ya esta cargado el resutado de ese partido');

        // ESTO HAY QUE CORREGIRLO, MAS BIEN VER QUE PONGO CUANDO NO VIENE UN POST
        return $this->response->redirect(base_url("/partidos/$id_partidos"));
        // return view('templates/header', $data)
        //     . view('templates/navbar')
        //     . view('templates/sidebar')
        //     . view('miprode/partido')
        //     . view('templates/footer');
    }



    public function bajaPartido($id = null)
    {
        $model = model(PartidosModel::class);
        $partido = $model->getPartidos($id);

        $model->where('id_partidos', $id)->delete();

      
        //dd($partido);
        $id_fase = $partido['fases_id_fases']; 

        return $this->response->redirect(base_url("/partidos/listapartidos/$id_fase"));
    }


    //LISTAR LAS FASES DEL ABM PARTIDOS
    public function listarFasesPartidos($id_torneos = null)
    {
        //TORNEO
        $modelTorneos = model(TorneosModel::class);
        $torneo = $modelTorneos->getTorneos($id_torneos);

        //FASES
        $modelFases = model(FasesModel::class);

        //dd($torneo);

        $data = [
            'fases'  => $modelFases->getFasesTorneo($id_torneos),
            'torneo' => $torneo
        ];


        return $this->mostrarAdmin($this->page, $data);
    }

    // LISTAR DEL ABM PARTIDOS
    public function listaPartidos($id_fases = null)
    {

        //FASES
        $modelFases = new FasesModel();
        $fase = $modelFases->getFase($id_fases);

        //dd($fase);
        //PRONOSTICOS
        $model = new PartidosModel();
        $items = $model->findByAndFase($id_fases);

        //dd($items);
        $data = array(
            'partidos' => $items,
            'id_fases' => $id_fases,
            'fase' => $fase
        );

        //EQUIPOS
        $modelEquipos = new EquiposModel();
        $data['equipos']  =  $modelEquipos->getEquipos();

        //GRUPOS
        $modelGrupos = new GruposModel();
        $data['grupos']  =  $modelGrupos->getGrupos();

        return $this->mostrarAdmin($this->page, $data);
    }




    //RESULTADOS
    public function listaTorneos($espartido = null)
    {
        $modelTorneos = model(TorneosModel::class);

        $data = [
            'torneos'  => $modelTorneos->getTorneos(),
        ];

        if (!$espartido) {

            return $this->mostrarAdmin($this->pageResultado, $data);
        } else {
            return $this->mostrarAdmin($this->page, $data);
        }
    }


    public function listarFases($id_torneos = null)
    {
        //TORNEO
        $modelTorneos = model(TorneosModel::class);
        $torneo = $modelTorneos->getTorneos($id_torneos);

        //FASES
        $modelFases = model(FasesModel::class);

        //dd($torneo);

        $data = [
            'fases'  => $modelFases->getFasesTorneo($id_torneos),
            'torneo' => $torneo
        ];


        return $this->mostrarAdmin($this->pageResultado, $data);
    }

    public function lista($id_fases = null)
    {

        //FASES
        $modelFases = new FasesModel();
        $fase = $modelFases->getFase($id_fases);

        //dd($fase);
        //PRONOSTICOS
        $model = new PartidosModel();
        $items = $model->findByAndFase($id_fases);

        //dd($items);
        $data = array(
            'partidos' => $items,
            'id_fases' => $id_fases,
            'fase' => $fase
        );



        return $this->mostrarAdmin($this->pageResultado, $data);
    }


    public function saveResultado()
    {

        $resultados = $this->request->getPost('resultado');



        $partido = new PartidosModel();


        foreach ($resultados as $key => $value) {

            $partido->save([
                'id_partidos' => $key ? $key : null,
                'resultado' => $value,

            ]);
        }


        $idfase = $this->request->getPost('id_fases');

        // //dd($idfase);

        // //FASES
        // $modelFases = new FasesModel();
        // $fase = $modelFases->getFase($idfase);
        // //dd($fase);

        // //dd($fase);
        // //PRONOSTICOS
        // $model = new PartidosModel();

        // $items = $model->findByAndFase($idfase);

        // $data = array(
        //     'partidos' => $items,
        //     'id_fases' => $idfase,
        //     'fase' => $fase
        // );

        //return $this->mostrarAdmin($this->pageResultado, $data);

        return $this->response->redirect(base_url("/partidos/lista/$idfase"));
    }
}
