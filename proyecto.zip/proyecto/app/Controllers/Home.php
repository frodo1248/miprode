<?php

namespace App\Controllers;

class Home extends BaseController
{
    
    private $page = 'home';
    
    public function index()
    {
        //return $this->response->redirect(base_url('/home'));
        

        return $this->mostrarAdmin($this->page);

        // return view('templates/header')//, $data)
        // . view('templates/navbar')
        // . view('templates/sidebar')
        // . view('miprode/home')
        // . view('templates/footer');

    }


    

}
