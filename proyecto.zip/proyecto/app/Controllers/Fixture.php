<?php

namespace App\Controllers;

use App\Models\PartidosModel;
use App\Models\FasesModel;
use App\Models\TorneosModel;
use App\Models\EquiposModel;
use App\Models\GruposModel;
use App\Models\PronosticosModel;
use Config\Services;

class Fixture extends BaseController
{

    protected $helpers = ['form'];
    public $page = 'fixture';

    public function index()
    {

        $modelTorneos = model(TorneosModel::class);

        $data = [
            'torneos'  => $modelTorneos->getTorneosPronosticosTodos(),
        ];

        //dd($data);
        return $this->mostrarAdmin($this->page, $data);
    }

    public function mostrar($id_torneo = null) {

        $model = model(PartidosModel::class);
        $modelFases = model(FasesModel::class);
        $modelGrupos = model(GruposModel::class);

        $partidos = $model->fixture($id_torneo);

        // $data = [
        //     'fixture' => $model->fixture($id_torneo),
        //     'fases' => $modelFases->getFasesTorneo($id_torneo),
        //     'partidos' => $model->getPartidos(),
        //     'grupos' => $modelGrupos->getGrupos(),
            


        // ];

        $torneo=[];
        foreach ($partidos as $p){

            if (!isset($torneo[$p->nombreTorneo])){
                $torneo[$p->nombreTorneo]=[];
            }
            if (!isset($torneo[$p->nombreTorneo][$p->nombreFase])){
                $torneo[$p->nombreTorneo][$p->nombreFase]=[];
            }
            if (!isset($torneo[$p->nombreTorneo][$p->nombreFase][$p->nombreGrupo])){
                $torneo[$p->nombreTorneo][$p->nombreFase][$p->nombreGrupo]=[];
            }
            // if (!isset($torneo[$p->nombreTorneo][$p->nombreFase][$p->nombreGrupo])){
            //     $torneo[$p->nombreTorneo][$p->nombreFase][$p->nombreGrupo]=[];
            // }
            
            $torneo[$p->nombreTorneo][$p->nombreFase][$p->nombreGrupo][]=[$p];

        }

        //dd($torneo);
        $data = [
            'torneo'  => $torneo
        ];
        return $this->mostrarAdmin($this->page, $data);

    }

   



    public function view($id_partidos = null)
    {
        $model = model(PartidosModel::class);
        $modelFases = model(FasesModel::class);
        $modelEquipos = model(EquiposModel::class);
        $modelGrupos = model(GruposModel::class);


        $data = [
            'partidos'  => $model->getPartidos(),
            'partido' => $model->getPartidos($id_partidos)
        ];


        $data['fases']  =  $modelFases->getFases();

        $data['equipos']  =  $modelEquipos->getEquipos();

        $data['grupos']  =  $modelGrupos->getGrupos();

        if (empty($data['partidos'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el partido: ' . $id_partidos);
        }



        return $this->mostrarAdmin($this->page, $data);
        // return view('templates/header', $data)
        //     . view('templates/navbar')
        //     . view('templates/sidebar')
        //     . view('miprode/partido')
        //     . view('templates/footer');
    }
}

