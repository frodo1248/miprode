<?php

namespace App\Controllers;

use App\Models\FasesModel;
use App\Models\InvitacionesModel;
use App\Models\TorneosModel;
use App\Models\DesafiosModel;
use App\Models\UsuariosModel;
use Config\Services;

class Invitaciones extends BaseController
{

    

    protected $helpers = ['form'];
    public $page = 'invitacion';

    public function index()
    {
        $model = model(InvitacionesModel::class);

        //$modelTorneos = model(TorneosModel::class);

        $data = [
            'misinvitaciones'  => $model->getMisInvitaciones(),
            'title' => 'Invitaciones'
        ];


        //$data['torneos']  =  $modelTorneos->getTorneos();

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/invitacion')
            . view('templates/footer');
    }


    public function view($id_fases = null)
    {
        $model = model(FasesModel::class);
        $modelTorneos = model(TorneosModel::class);

        $data = [
            //'fases'  => $model->getFases(),
            'fase' => $model->getFases($id_fases)
        ];

        //dd($data['fase']['torneos_id_torneos']);
        //$torneo = $modelTorneos->getTorneos($data['fase']['torneos_id_torneos']);

        $data['torneo']  =  $modelTorneos->getTorneos($data['fase']['torneos_id_torneos']);
        
        $data['fases']  = $model->getFasesTorneo($data['fase']['torneos_id_torneos']);

        //$data['torneos']  =  $modelTorneos->getTorneos();

        //dd($data);

        if (empty($data['fases'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar la fase: ' . $id_fases);
        }


        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/fase')
            . view('templates/footer');
    }

    //ACAAAAAAAAAAAAAAAAA
    public function crearInvitacion($id_desafios = null)
    {
        
        //dd('llegue');
        
        $model = model(InvitacionesModel::class);

        $modelTorneos = model(TorneosModel::class);

        $modelDesafios = model(DesafiosModel::class);

        $data = [
            'invitaciones'  => $model->getMisInvitaciones(),
            'title' => 'Fases',
            'desafio'  => $modelDesafios->getDesafios($id_desafios),
        ];


        $data['torneos']  =  $modelTorneos->getTorneos();

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view("miprode/$this->page")
            . view('templates/footer');
    }

  
    public function saveInvitacion($nombre = null)
    {
        
        //dd('llegue');
        
        $model = model(InvitacionesModel::class);

        $modelUsuarios = model(UsuariosModel::class);

        $id_usuario = session()->id_usuarios;
        
        

        $id_desafio = $this->request->getPost('id_desafios');

        $id_invitado = $modelUsuarios->getId($this->request->getPost('nombre'));

        //dd($id_invitado['id_usuarios']);

        //$data['fases'] = $model->getFases();
        $data['usuarios'] = $modelUsuarios->getUsuarios();

        $data['validation']  = Services::validation();

        $mensaje['error'] = 'Ya existe esa fase en la BD';

        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                'rules'  => 'required|is_unique[usuarios.nombre,id_usuarios,{id_usuarios}]|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe esa fases en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
              

            ]
        ])) { 
            

            //dd($id_usuario);

            $invitacion = [
            
                'id_desafios' => $id_desafio,
                'id_invitado' => $id_invitado['id_usuarios'],
                'id_anfitrion' => $id_usuario,

            ];
            
            //dd($invitacion);

            $model->save($invitacion);
           

            return $this->response->redirect(base_url("/invitaciones/crearinvitacion/$id_desafio"));
        }

       //dd($data);

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/fase')
            . view('templates/footer');
    }



    public function bajaInvitacion($id = null)
    {
       
        
        $model = model(InvitacionesModel::class);

        $invitacion = $model->getInvitaciones($id);
        //dd($fase->torneos_id_torneos);
        $id_desafio = $invitacion['id_desafios'];

        $model->where('id_invitaciones', $id)->delete();

        

        return $this->response->redirect(base_url("/invitaciones/crearinvitacion/$id_desafio"));
    }

}
