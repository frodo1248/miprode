<?php

namespace App\Controllers;

use App\Models\TorneosModel;
use Config\Services;

class Torneos extends BaseController
{

    protected $helpers = ['form'];

    public function index()
    {
        $model = model(TorneosModel::class);

        $data = [
            'torneos'  => $model->getTorneos(),
            'title' => 'Torneos'
        ];


        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/torneo')
            . view('templates/footer');
    }


    public function view($id_torneos = null)
    {
        $model = model(TorneosModel::class);


        $data = [
            'torneos'  => $model->getTorneos(),
            'torneo' => $model->getTorneos($id_torneos)
        ];


        //dd($data);

        if (empty($data['torneos'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el torneo: ' . $id_torneos);
        }


        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/torneo')
            . view('templates/footer');
    }


    public function saveTorneo($nombre = null)
    {
        $model = model(TorneosModel::class);

        $data['torneos'] = $model->getTorneos();

        $data['validation']  = Services::validation();

        //$mensaje['error'] = 'Ya existe ese torneo en la BD';
        //dd($this->request->getPost('fecha_ini'));
        $fechaPost = $this->request->getPost('fecha_ini');
        $fecha = date('Y-m-d');
        //dd($fecha);

        // if ($this->request->getPost('fecha_ini') > $fecha) {
        //     dd('es menor');
        // }


        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                'rules'  => 'required|is_unique[torneos.nombre,id_torneos,{id_torneos}]|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe ese torneo en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
            ]
            // ],
            // 'fecha_ini' => [
            //     'rules'  => "required|greater_than[$fecha]",
            //     'errors' => [
            //         'required' => 'Debe completar el campo Fecha de Inicio.',
            //         'greater_than' => 'La Fecha de Inicio no puede ser menor a la Fecha Actual',

            //     ]
            // ]
        ])) {

            $model->save([
                'id_torneos' => $this->request->getPost('id_torneos'),
                'nombre' => $this->request->getPost('nombre'),
                'fecha_ini' => $this->request->getPost('fecha_ini'),
                'fecha_fin' => $this->request->getPost('fecha_fin'),

            ]);


            return $this->response->redirect(base_url('/torneos'));
        }

        //dd($data);

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/torneo')
            . view('templates/footer');
    }



    public function bajaTorneo($id = null)
    {
        $model = model(TorneosModel::class);

        $model->where('id_torneos', $id)->delete();

        return $this->response->redirect(base_url('/torneos'));
    }
}
