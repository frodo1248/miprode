<?php

namespace App\Controllers;

use App\Models\EquiposModel;
use Config\Services;

class Equipos extends BaseController
{

    protected $helpers = ['form'];

    public function index()
    {
        $model = model(EquiposModel::class);

        $data = [
            'equipos'  => $model->getEquipos(),
            'title' => 'Equipos'
        ];


        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/equipo')
            . view('templates/footer');
    }

    public function view($id_equipos = null)
    {
        $model = model(EquiposModel::class);


        $data = [
            'equipos'  => $model->getEquipos(),
            'equipo' => $model->getEquipos($id_equipos)
        ];


        //dd($data);

        if (empty($data['equipos'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el equipo: ' . $id_equipos);
        }

        //$data['title'] = $data['equipos']['title'];

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/equipo')
            . view('templates/footer');
    }


    public function saveEquipo($nombre = null)
    {
        $model = model(EquiposModel::class);

        $data['equipos'] = $model->getEquipos();

        $data['validation']  = Services::validation();

        //$mensaje['error'] = 'Ya existe ese equipo en la BD';

        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                'rules'  => 'required|is_unique[equipos.nombre,id_equipos,{id_equipos}]|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe ese equipo en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
            

            ]
        ])) { //se puede poner en español el mensaje, ver el validate

            //dd($this->request->getPost('id_equipos'));
            $model->save([
                'id_equipos' => $this->request->getPost('id_equipos'),
                'nombre' => $this->request->getPost('nombre'),

            ]);


            return $this->response->redirect(base_url('/equipos'));
        }

        //$data['title'] = $data['equipos']['title'];

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/equipo')
            . view('templates/footer');
    }



    public function bajaEquipo($id = null)
    {
        $model = model(EquiposModel::class);

        $model->where('id_equipos', $id)->delete();

        return $this->response->redirect(base_url('/equipos'));
    }
}
