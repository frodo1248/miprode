<?php

namespace App\Controllers;

use App\Models\UsuariosModel;
use Config\Services;

class Usuarios extends BaseController
{
    private $page = 'usuario';

    protected $helpers = ['form'];

    public function index()
    {
        $model = model(UsuariosModel::class);

        $data = [
            'usuarios'  => $model->getUsuarios(),
            'title' => 'Usuarios'
        ];


        return $this->mostrarAdmin($this->page, $data);
       
    }

    public function indexParticipante()
    {
        $model = model(UsuariosModel::class);

        $data = [
            'usuarios'  => $model->getUsuarios(),
            'title' => 'Usuarios'
        ];


        return $this->mostrarParticipante($this->page, $data);
       
    }

    public function view($id_usuarios = null)
    {
        $model = model(UsuariosModel::class);


        $data = [
            'usuarios'  => $model->getUsuarios(),
            'usuario' => $model->getUsuarios($id_usuarios)
        ];


        //dd($data);

        if (empty($data['usuarios'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el usuario: ' . $id_usuarios);
        }

        

        return $this->mostrarAdmin($this->page, $data);
    }


    public function saveUsuario($nombre = null)
    {
        //dd('llega');
        $model = model(UsuariosModel::class);

        $data['usuarios'] = $model->getUsuarios();

        $data['validation']  = Services::validation();

        $mensaje['error'] = 'Ya existe ese usuario en la BD';

        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                'rules'  => 'required|is_unique[usuarios.usuario,id_usuarios,{id_usuarios}]|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe ese usuario en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
            

            ]
        ])) { //se puede poner en español el mensaje, ver el validate

          
            $model->save([
                'id_usuarios' => $this->request->getPost('id_usuarios'),
                'dni' => $this->request->getPost('dni'),
                'nombre' => $this->request->getPost('nombre'),
                'apellido' => $this->request->getPost('apellido'),
                'usuario' => $this->request->getPost('usuario'),
                'clave' => $this->request->getPost('clave'),
                'email' => $this->request->getPost('email'),
                'fecha_nac' => $this->request->getPost('fecha_nac'),
                'rol' => $this->request->getPost('rol')

            ]);


            return $this->response->redirect(base_url('/'));
        }

     

        return $this->mostrarAdmin($this->page, $data);
    }



    public function bajaUsuario($id = null)
    {
        $model = model(UsuariosModel::class);

        $model->where('id_usuarios', $id)->delete();

        return $this->response->redirect(base_url('/usuarios'));
    }
}
