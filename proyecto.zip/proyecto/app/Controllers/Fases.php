<?php

namespace App\Controllers;

use App\Models\FasesModel;
use App\Models\TorneosModel;
use Config\Services;

class Fases extends BaseController
{

    

    protected $helpers = ['form'];
    public $page = 'fase';

    public function index()
    {
        $model = model(FasesModel::class);

        $modelTorneos = model(TorneosModel::class);

        $data = [
            'fases'  => $model->getFases(),
            'title' => 'Fases'
        ];


        $data['torneos']  =  $modelTorneos->getTorneos();

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/fase')
            . view('templates/footer');
    }


    public function view($id_fases = null)
    {
        $model = model(FasesModel::class);
        $modelTorneos = model(TorneosModel::class);

        $data = [
            //'fases'  => $model->getFases(),
            'fase' => $model->getFases($id_fases)
        ];

        //dd($data['fase']['torneos_id_torneos']);
        //$torneo = $modelTorneos->getTorneos($data['fase']['torneos_id_torneos']);

        $data['torneo']  =  $modelTorneos->getTorneos($data['fase']['torneos_id_torneos']);
        
        $data['fases']  = $model->getFasesTorneo($data['fase']['torneos_id_torneos']);

        //$data['torneos']  =  $modelTorneos->getTorneos();

        //dd($data);

        if (empty($data['fases'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar la fase: ' . $id_fases);
        }


        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/fase')
            . view('templates/footer');
    }

    public function mostrarFase($id_torneos = null)
    {


        //dd('andaaaaaa');
        //TORNEO
        $modelTorneos = model(TorneosModel::class);
        $torneo = $modelTorneos->getTorneos($id_torneos);

        //FASES
        $modelFases = model(FasesModel::class);

        //dd($torneo);

        $data = [
            'fases'  => $modelFases->getFasesTorneo($id_torneos),
            'torneo' => $torneo //esto lo hice recien para el volver Fases
        ];


        return $this->mostrarAdmin($this->page, $data);
    }



    public function saveFase($nombre = null)
    {
        $model = model(FasesModel::class);

        //$data['fases'] = $model->getFases();
        $data['fases'] = $model->getFasesTorneo($this->request->getPost('torneos_id_torneos'));

        $data['validation']  = Services::validation();

        $mensaje['error'] = 'Ya existe esa fase en la BD';

        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                //'rules'  => 'required|is_unique[fases.nombre,id_fases,{id_fases}]|min_length[3]', deberia verificar el valor unico compuesto por el nombre y la fk de torneo
                'rules'  => 'required|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe esa fases en la BD.',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
              

            ]
        ])) { 
            
            //dd($this->request->getPost('torneos_id_torneos'));
            $fase = [
                'id_fases' => $this->request->getPost('id_fases'),
                'nombre' => $this->request->getPost('nombre'),
                'fecha_ini' => $this->request->getPost('fecha_ini'),
                'fecha_fin' => $this->request->getPost('fecha_fin'),
                'es_eliminatoria' => $this->request->getPost('es_eliminatoria'),
                'torneos_id_torneos' => $this->request->getPost('torneos_id_torneos'),

            ];
            
            $fk =$this->request->getPost('torneos_id_torneos');

            //dd($model);

            $model->save($fase);
            $id_torneo = $this->request->getPost('torneos_id_torneos');

            return $this->response->redirect(base_url("/fases/mostrarfase/$id_torneo"));
        }

       //dd($data);

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/fase')
            . view('templates/footer');
    }



    public function bajaFase($id = null)
    {
       
        
        $model = model(FasesModel::class);

        $fase = $model->getFase($id);
        //dd($fase->torneos_id_torneos);
        $id_torneo = $fase->torneos_id_torneos;

        $model->where('id_fases', $id)->delete();

        

        return $this->response->redirect(base_url("/fases/mostrarfase/$id_torneo"));
    }

}
