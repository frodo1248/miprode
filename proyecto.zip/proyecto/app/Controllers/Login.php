<?php

namespace App\Controllers;

use App\Models\UsuariosModel;

use Config\Services;

class Login extends BaseController
{

    //protected $helpers = ['form'];

    public function index()
    {
        // $model = model(FasesModel::class);

        // $modelTorneos = model(TorneosModel::class);

        // $data = [
        //     'fases'  => $model->getFases(),
        //     'title' => 'Fases'
        // ];


        // $data['torneos']  =  $modelTorneos->getTorneos();

        return view('templates/header') //, $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/login')
            . view('templates/footer');
    }


    public function logeo()
    {




        //$usuario = $this->request->getPost('usuario');

        //dd($usuario);
        $usuario = $this->request->getPost('usuario');

        $model = model(UsuariosModel::class);
        $data['usuario'] = $model->loginUsuario($usuario);

        if ($data['usuario'] != null) {



            // $data['validation']  = Services::validation();

            // $mensaje['error'] = 'Ya existe esa fase en la BD';
            //dd($this->request->getPost('contraseña'));
            //dd($data['usuario']['clave']);
            //dd($data);


            if ($data['usuario']['clave'] == $this->request->getPost('contraseña')) {

                
                $sessions = session();

                $nuevoUsuario = [
                    'id_usuarios' => $data['usuario']['id_usuarios'],
                    'nombre' => $data['usuario']['nombre'],
                    'apellido' => $data['usuario']['apellido'],
                    'usuario' => $usuario,
                    'email' => $data['usuario']['email'],
                    'rol' => $data['usuario']['rol'],
                    'logged' => true,
                ];

                $sessions->set($nuevoUsuario);




                //$session()->username; //usar esto

                return $this->response->redirect(base_url('/home'));
                // return view('templates/header', $data)
                //     . view('templates/navbar')
                //     . view('templates/sidebar')
                //     . view('miprode/home')
                //     . view('templates/footer');
            }

            //'nombre' => $this->request->getPost('nombre'),

            dd('clave incorrecta');
        } else {
            $this->index();
        }
    }

    public function logeoOriginal()
    {
        //$usuario = $this->request->getPost('usuario');

        //dd($usuario);
        $usuario = $this->request->getPost('usuario');

        $model = model(UsuariosModel::class);
        $data['usuario'] = $model->loginUsuario($usuario);

        if ($usuario != null and $data['usuario'] != null) {



            // $data['validation']  = Services::validation();

            // $mensaje['error'] = 'Ya existe esa fase en la BD';
            //dd($this->request->getPost('contraseña'));
            //dd($data['usuario']['clave']);
            if ($data['usuario']['usuario'] == $usuario) {

                if ($data['usuario']['clave'] == $this->request->getPost('contraseña')) {
                    return view('templates/header', $data)
                        . view('templates/navbar')
                        . view('templates/sidebar')
                        . view('miprode/home')
                        . view('templates/footer');
                }
            }
            //'nombre' => $this->request->getPost('nombre'),

            dd('clave incorrecta');
        } else {
            dd('no esta en la base');
        }
    }

    public function cerrarSesion()
    {

        //dd('cerrar sesion');
        session()->destroy();
       
        
        return $this->response->redirect(base_url('/'));
    }


    //public fuction index()

    //$sessions = session()

    // $newdata = [
    //     'username' => 'si',
    //     'email' => 'si.com',
    //     'logged_in' => true,
    //     ];

    // $session --> set($newdata)


    // $session->username;
    // /puedo usar una o la otra
    // $_SESSION['username']

    // $session()->username //usar esto

}
