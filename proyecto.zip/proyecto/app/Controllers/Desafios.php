<?php

namespace App\Controllers;

use App\Models\DesafiosModel;
use App\Models\TorneosModel;
use Config\Services;

class Desafios extends BaseController
{

    protected $helpers = ['form'];
    public $page = 'desafio';

    public function index()
    {
        $model = model(DesafiosModel::class);//esto es al pedo

        $modelTorneos = model(TorneosModel::class);

        $data = [
            'desafios'  => $model->getDesafios(),
            'title' => 'Desafios'
        ];

        $data['torneos']  =  $modelTorneos->getTorneosPronosticos();

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/desafio')
            . view('templates/footer');
    }

    public function view($id_desafios = null)
    {
        $model = model(DesafiosModel::class);


        $data = [
            'desafios'  => $model->getDesafios(),
            'desafio' => $model->getDesafios($id_desafios)
        ];


        //dd($data);

        if (empty($data['desafios'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('No pudo encontrar el desafio: ' . $id_desafios);
        }

        //$data['title'] = $data['equipos']['title'];

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/desafio')
            . view('templates/footer');
    }
    



    public function altaDesafio($id_torneos = null)
    {


        //DESAFIOS
        $model = model(DesafiosModel::class);

        //TORNEO
        $modelTorneos = model(TorneosModel::class);
        $torneo = $modelTorneos->getTorneos($id_torneos);


        //dd($torneo);

        $data = [
            'torneo' => $torneo, //esto lo hice recien para el volver Fases
            'desafios'  => $model->getDesafios(),
        ];


        return $this->mostrarAdmin($this->page, $data);
    }



    public function saveDesafio($nombre = null)
    {


        //dd('falta hacer el save');

        $id_usuario = session()->id_usuarios;
        $id_torneo = $this->request->getPost('torneos_id_torneos');


        //dd($id_usuario);

        $model = model(DesafiosModel::class);

        $data['desafios'] = $model->getDesafios();

        $data['validation']  = Services::validation();

        //$mensaje['error'] = 'Ya existe ese equipo en la BD';

        //Ver si pongo en la table desafios un estado
        if ($this->request->getMethod() === 'post' && $this->validate([
            'nombre' => [
                'rules'  => 'required|is_unique[desafios.nombre,id_desafios,{id_desafios}]|min_length[3]',
                'errors' => [
                    'required' => 'Debe completar el campo nombre.',
                    'is_unique' => 'Ya existe un desafio con ese nombre',
                    'min_length' => 'Debe tener mas de dos caracteres'
                ]
            

            ]
        ])) { //se puede poner en español el mensaje, ver el validate

            //dd($this->request->getPost('id_desafios'));
            $model->save([
                'nombre' => $this->request->getPost('nombre'),
                'id_usuarios' => $id_usuario,
                'id_torneos' => $id_torneo,

            ]);


            return $this->response->redirect(base_url("/desafios/creardesafio/$id_torneo"));
        }

        //$data['title'] = $data['equipos']['title'];

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            . view('miprode/equipo')
            . view('templates/footer');
    }



    public function misDesafios()
    {
        $model = model(DesafiosModel::class);//esto es al pedo

        //$modelTorneos = model(TorneosModel::class);

        $data = [
            'misDesafios'  => $model->getMisDesafios(),
            'title' => 'Desafios'
        ];

        //$data['torneos']  =  $modelTorneos->getTorneosPronosticos();

        return view('templates/header', $data)
            . view('templates/navbar')
            . view('templates/sidebar')
            //. view('templates/nav')
            . view('miprode/desafio')
            . view('templates/footer');
    }



    
}
